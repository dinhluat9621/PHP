-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 17, 2017 at 07:45 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `qlbh`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `ID` int(11) NOT NULL,
  `Username` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `Password` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`ID`, `Username`, `Password`) VALUES
(12457, 'admin2', '123456'),
(13584, 'admin1', 'admin1234');

-- --------------------------------------------------------

--
-- Table structure for table `chitietsanpham`
--

CREATE TABLE `chitietsanpham` (
  `ID_SanPham` int(11) NOT NULL,
  `MauSP` varchar(100) CHARACTER SET utf8 COLLATE utf8_vietnamese_ci NOT NULL,
  `SoLuong` int(11) NOT NULL,
  `Gia` int(100) NOT NULL,
  `Anh` varchar(200) CHARACTER SET utf8 COLLATE utf8_vietnamese_ci NOT NULL,
  `GiaKM` int(11) NOT NULL,
  `TinhTrang` varchar(50) CHARACTER SET utf8 COLLATE utf8_vietnamese_ci NOT NULL,
  `SoLuongDaBan` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `chitietsanpham`
--

INSERT INTO `chitietsanpham` (`ID_SanPham`, `MauSP`, `SoLuong`, `Gia`, `Anh`, `GiaKM`, `TinhTrang`, `SoLuongDaBan`) VALUES
(1, 'NÃ¢u', 93, 200000, 'ChÃ¬ káº» máº¯t YSL Dessin du Regard Eye Pencil - 210.000.jpg', 0, 'cÃ²n hÃ ng', 29),
(2, 'Äen', 20, 120000, 'MAC Powerpoint eyeliner - 320.000.jpg', 0, '', 12),
(3, 'Đen', -8, 300000, 'NYX Liquid Black Liner - 200.000.jpg', 0, '', 13),
(4, 'NÃ¢u', 0, 150000, 'Maybelline HyperSharp Wing Liquid Liner -160.000.jpg', 0, '', 5),
(12, 'Äá»', 0, 765000, 'Chanel Rouge Allure Velvet Luminous Matte Lip Colour in La Petillante â€“ 756.000 Ä‘á»“ng.jpg', 0, '', 0),
(13, '', 0, 0, 'Charlotte Tilbury Matte Revolution Lipstick - 940.000 Ä‘Ã´Ì€ng.jpg', 0, '', 0),
(15, 'Äá»', 12, 765000, 'Chanel Rouge Allure Velvet Luminous Matte Lip Colour in La Petillante â€“ 756.000 Ä‘á»“ng.jpg', 0, '', 0),
(16, '', 0, 0, 'Guerlain Rouge G Jewel Lipstick Compact - 1.137.000 Ä‘á»“ng.jpg', 0, '', 0),
(17, '', 0, 0, 'Christian Dior Rouge No. 999 Lipstick - 758.000 Ä‘á»“ng.jpg', 0, '', 0),
(18, '', 0, 0, 'Givenchy Le Rouge Rose Dressing Lipstick - 802.000 Ä‘á»“ng.jpg', 0, '', 0),
(19, '', 0, 0, 'Son Burberry Lip Velvet Matte - 900.000 Ä‘Ã´Ì€ng.jpg', 0, '', 0),
(20, '', 0, 0, 'son-mac-russian-red-2563536595_46728356_1000x1250.jpg', 0, '', 0),
(21, '', 0, 0, 'Yves Saint Laurent Rouge Volupte Shine - 825.000 Ä‘á»“ng.jpg', 0, '', 0),
(23, '', 0, 0, 'Tom Ford Moisturecore Lip Color - 1.226.000 Ä‘á»“ng.jpg', 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `danhmucsanpham`
--

CREATE TABLE `danhmucsanpham` (
  `ID_DanhMuc` int(11) NOT NULL,
  `TenDanhMuc` varchar(50) CHARACTER SET utf8 COLLATE utf8_vietnamese_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `danhmucsanpham`
--

INSERT INTO `danhmucsanpham` (`ID_DanhMuc`, `TenDanhMuc`) VALUES
(1, 'Mắt'),
(2, 'Môi'),
(3, 'Mặt'),
(4, 'Móng');

-- --------------------------------------------------------

--
-- Table structure for table `dathang`
--

CREATE TABLE `dathang` (
  `ID_KH` int(11) NOT NULL,
  `ID_SanPham` int(10) NOT NULL,
  `TenSanPham` varchar(100) CHARACTER SET utf8 COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `SoLuong` int(100) DEFAULT NULL,
  `ThanhTien` int(200) DEFAULT NULL,
  `NgayDat` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `giohang`
--

CREATE TABLE `giohang` (
  `ID_GioHang` int(11) NOT NULL,
  `ID_SanPham` int(11) NOT NULL,
  `SoLuong` int(11) NOT NULL,
  `GiaTien` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `ThanhTien` varchar(10) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `khachhang`
--

CREATE TABLE `khachhang` (
  `ID_KH` int(11) NOT NULL,
  `HoTen` varchar(255) CHARACTER SET utf8 COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `DiaChi` varchar(255) CHARACTER SET utf8 COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `Quan_Huyen` varchar(100) CHARACTER SET utf8 COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `Tinh` varchar(100) CHARACTER SET utf8 COLLATE utf8_vietnamese_ci DEFAULT NULL,
  `SoDienThoai` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Email` varchar(255) CHARACTER SET utf8 COLLATE utf8_vietnamese_ci NOT NULL,
  `MatKhau` varchar(255) CHARACTER SET utf8 COLLATE utf8_vietnamese_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `khachhang`
--

INSERT INTO `khachhang` (`ID_KH`, `HoTen`, `DiaChi`, `Quan_Huyen`, `Tinh`, `SoDienThoai`, `Email`, `MatKhau`) VALUES
(1, 'Nguyễn Văn Lâm', NULL, NULL, NULL, '0', 'lamnv@gmail.com', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `lienhe`
--

CREATE TABLE `lienhe` (
  `ID_LienHe` int(11) NOT NULL,
  `HoTen` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `SoDienThoai` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `NoiDung` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `loaisanpham`
--

CREATE TABLE `loaisanpham` (
  `ID_LoaiSP` int(11) NOT NULL,
  `TenLoaiSP` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TenDanhMuc` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `loaisanpham`
--

INSERT INTO `loaisanpham` (`ID_LoaiSP`, `TenLoaiSP`, `TenDanhMuc`) VALUES
(1, 'Pháº¥n máº¯t', '1'),
(2, 'Káº» máº¯t', '1'),
(3, 'Mascara', '1'),
(4, 'Cá» máº¯t', '1'),
(5, 'Son bÃ³ng', '2'),
(6, 'Son mÃ´i', '2'),
(7, 'Cá» mÃ´i', '2'),
(8, 'DÆ°á»¡ng da', '3'),
(9, 'Kem ná»n', '3'),
(10, 'Che khuyáº¿t Ä‘iá»ƒm', '3'),
(11, 'Pháº¥n & mÃ¡ há»“ng', '3'),
(12, 'SÆ¡n mÃ³ng', '4'),
(13, 'Dá»¥ng cá»¥', '4');

-- --------------------------------------------------------

--
-- Table structure for table `sanpham`
--

CREATE TABLE `sanpham` (
  `ID_SanPham` int(11) NOT NULL,
  `ID_LoaiSP` int(11) NOT NULL,
  `TenSanPham` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `ThongTinSP` text COLLATE utf8_unicode_ci NOT NULL,
  `HuongDanSD` text COLLATE utf8_unicode_ci NOT NULL,
  `NgayThem` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sanpham`
--

INSERT INTO `sanpham` (`ID_SanPham`, `ID_LoaiSP`, `TenSanPham`, `ThongTinSP`, `HuongDanSD`, `NgayThem`) VALUES
(0, 11, '', '', '', '2017-06-17'),
(1, 2, 'YSL Dessin du Regard Eye Pencil', '', '', '2017-06-06'),
(2, 3, 'MAC Powerpoint eyeliner', '', '', '2017-06-07'),
(3, 2, 'Stila Eyeliner', '', '', '2017-05-15'),
(4, 2, ' OrÃ©al SuperLiner Gel Eyeliner', '', '', '2017-04-11'),
(5, 1, 'Tarte Tartelette Amazonian Eye Shadow Palette', '', '', '2017-03-20'),
(6, 1, 'The Royal Peach Palette', '', '', '2017-04-20'),
(7, 1, 'Too Faced Chocolate Bar Eyeshadow Collection', '', '', '2017-05-27'),
(8, 1, 'Too Faced Sweet Peach Eyeshadow Palette', '', '', '2017-06-02'),
(9, 1, 'Urban Decay Naked Smoky', '', '', '2017-04-15'),
(10, 1, 'Shiseido Festive Camellia', '', '', '2017-02-20'),
(11, 3, 'Sephora Eyeliner', '', '', '2017-06-17'),
(12, 6, 'Chanel Rouge Allure Velvet Luminous', '', '', '2017-06-17'),
(13, 6, 'Charlotte Tilbury Matte Revolution Lipstick', '', '', '2017-06-17'),
(15, 6, 'Christian Louboutin Lip Colour', '', '', '2017-06-17'),
(16, 6, 'Dolce & Gabbana Monica Voluptuous Lipstick', '', '', '2017-06-17'),
(17, 6, 'Givenchy Le Rouge Rose Dressing Lipstick', '', '', '2017-06-17'),
(18, 6, 'Guerlain Rouge G Jewel Lipstick Compact', '', '', '2017-06-17'),
(19, 6, 'Mac Retro Matte Liquid LipColor', '', '', '2017-06-17'),
(20, 6, 'Sisley Hydrating Long Lasting Lipstick', '', '', '2017-06-17'),
(21, 6, 'Son Burberry Lip Velvet Matte', '', '', '2017-06-17'),
(23, 6, 'Yves Saint Laurent Rouge Volupte Shine', '', '', '2017-06-17'),
(24, 1, 'sdrfdfdfdf', '', '', '2017-06-17'),
(25, 1, 'qqqqqqqqqqqqqqqqqqq', '', '', '2017-06-17');

-- --------------------------------------------------------

--
-- Table structure for table `thongtingiaohang`
--

CREATE TABLE `thongtingiaohang` (
  `ID_KH` int(11) NOT NULL,
  `Email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NguoiNhan` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SoDienThoai` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Fax` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DiaChi` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Quan_Huyen` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Tinh` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `GhiChu` text COLLATE utf8_unicode_ci,
  `NgayDat` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tinh`
--

CREATE TABLE `tinh` (
  `ID_Tinh` int(11) NOT NULL,
  `TenTinh` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `chitietsanpham`
--
ALTER TABLE `chitietsanpham`
  ADD PRIMARY KEY (`ID_SanPham`);

--
-- Indexes for table `danhmucsanpham`
--
ALTER TABLE `danhmucsanpham`
  ADD PRIMARY KEY (`ID_DanhMuc`);

--
-- Indexes for table `dathang`
--
ALTER TABLE `dathang`
  ADD PRIMARY KEY (`ID_KH`,`ID_SanPham`),
  ADD KEY `ID_SanPham` (`ID_SanPham`);

--
-- Indexes for table `giohang`
--
ALTER TABLE `giohang`
  ADD PRIMARY KEY (`ID_GioHang`),
  ADD KEY `FK_SP_GH` (`ID_SanPham`);

--
-- Indexes for table `khachhang`
--
ALTER TABLE `khachhang`
  ADD PRIMARY KEY (`ID_KH`,`Email`);

--
-- Indexes for table `lienhe`
--
ALTER TABLE `lienhe`
  ADD PRIMARY KEY (`ID_LienHe`);

--
-- Indexes for table `loaisanpham`
--
ALTER TABLE `loaisanpham`
  ADD PRIMARY KEY (`ID_LoaiSP`,`TenDanhMuc`);

--
-- Indexes for table `sanpham`
--
ALTER TABLE `sanpham`
  ADD PRIMARY KEY (`ID_SanPham`),
  ADD KEY `ID_LoaiSP` (`ID_LoaiSP`);

--
-- Indexes for table `thongtingiaohang`
--
ALTER TABLE `thongtingiaohang`
  ADD PRIMARY KEY (`ID_KH`,`NgayDat`);

--
-- Indexes for table `tinh`
--
ALTER TABLE `tinh`
  ADD PRIMARY KEY (`ID_Tinh`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dathang`
--
ALTER TABLE `dathang`
  MODIFY `ID_KH` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `khachhang`
--
ALTER TABLE `khachhang`
  MODIFY `ID_KH` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `loaisanpham`
--
ALTER TABLE `loaisanpham`
  MODIFY `ID_LoaiSP` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `chitietsanpham`
--
ALTER TABLE `chitietsanpham`
  ADD CONSTRAINT `chitietsanpham_ibfk_1` FOREIGN KEY (`ID_SanPham`) REFERENCES `sanpham` (`ID_SanPham`);

--
-- Constraints for table `dathang`
--
ALTER TABLE `dathang`
  ADD CONSTRAINT `FK_DH_KH` FOREIGN KEY (`ID_KH`) REFERENCES `khachhang` (`ID_KH`),
  ADD CONSTRAINT `dathang_ibfk_1` FOREIGN KEY (`ID_KH`) REFERENCES `khachhang` (`ID_KH`),
  ADD CONSTRAINT `dathang_ibfk_2` FOREIGN KEY (`ID_SanPham`) REFERENCES `sanpham` (`ID_SanPham`),
  ADD CONSTRAINT `dathang_ibfk_3` FOREIGN KEY (`ID_KH`) REFERENCES `khachhang` (`ID_KH`);

--
-- Constraints for table `giohang`
--
ALTER TABLE `giohang`
  ADD CONSTRAINT `giohang_ibfk_1` FOREIGN KEY (`ID_SanPham`) REFERENCES `chitietsanpham` (`ID_SanPham`);

--
-- Constraints for table `sanpham`
--
ALTER TABLE `sanpham`
  ADD CONSTRAINT `sanpham_ibfk_1` FOREIGN KEY (`ID_LoaiSP`) REFERENCES `loaisanpham` (`ID_LoaiSP`);

--
-- Constraints for table `thongtingiaohang`
--
ALTER TABLE `thongtingiaohang`
  ADD CONSTRAINT `FK_KH_GH` FOREIGN KEY (`ID_KH`) REFERENCES `khachhang` (`ID_KH`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
