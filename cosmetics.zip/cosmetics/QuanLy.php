
<!DOCTYPE html>
<html>
<head>
	<title>Quản lý sản phẩm</title>
	<link rel="stylesheet" href="views/css/dangnhap.css">
	<link rel="stylesheet" href="views/css/cosmetic.css">
	<link rel="stylesheet" type="text/css" href="views/css/mat.css">
	<link rel="stylesheet" type="text/css" href="views/css/quanly.css">
	<link rel="stylesheet" href="views/css/bootstrap.min.css">
</head>
<body>
	
	<div id="navigation">
		<ul>
			<li><a href="#">BLOG LÀM ĐẸP</a></li>
			<li><a href="LienHe.php">LIÊN HỆ</a></li>
			<li><a href="#">GIỎ HÀNG</a></li>
	      	<li class="sign" style="border-style:none;">
	        	<form action="models/timkiem.php" method="post" accept-charset="utf-8" enctype="multipart/form-data">
	          		<input type="submit" id="searchbtn" name="search" value="Tìm kiếm" style="border-style: solid; color: white; font-size: 10px; background: #111; float: left; margin-top: 4px; margin-left: 45px;); height: 24px; width: 50px;">
	        	</form>
	      	</li>
			<li class="sign" >
		        <form action="" method="post">
		          <input type="search" id="searchf" name="searchtext" style="margin-right: -43px;" placeholder="Tìm kiếm...">
		        </form>
      		</li>  
			<li class="sign" style="margin-left: 20px;"><a href="views/DangNhap.php">Đăng xuất</a></li>
		</ul>
	</div>
	<div class="col-md-2" id="left"></div>
	<div class="col-md-8" id="content">
		<?php
    		include ("views/logo.php");
		?>
    		<h1 style="font-family: arial,helvetica,sans-serif; text-align: center; font-weight: bold;">Quản lý sản phẩm</h1>
    		<h5 style="font-family: arial,helvetica,sans-serif; text-align: center; font-weight: bold;">ADMIN: <?php echo $_GET['id_admin'] ?></h5>
	<div id="menu">
		<ul>
			<li style="width: 100px;"><a href="views/admin.php?xem=trangchu&id_admin=<?php echo $_GET['id_admin'] ?>">Trang chủ</a></li>
			<li style="width: 150px;"><a href="QuanLy.php?quanly=quanlyloaisp&ac=them&id_admin=<?php echo $_GET['id_admin'] ?>">Quản lý loại sản phẩm</a></li>
			<li style="width: 150px;"><a href="QuanLy.php?quanly=quanlysp&ac=them&id_admin=<?php echo $_GET['id_admin'] ?>">Quản lý sản phẩm</a></li>
			<li style="width: 140px;"><a href="QuanLy.php?quanly=quanlytk&ac=them&id_admin=<?php echo $_GET['id_admin'] ?>">Quản lý tài khoản</a></li>
			<li style="width: 140px;"><a href="QuanLy.php?quanly=quanlyhd&ac=them&id_admin=<?php echo $_GET['id_admin'] ?>">Quản lý hóa đơn</a></li>
			<li style="width: 140px;"><a href="QuanLy.php?quanly=quanlybl&ac=them&id_admin=<?php echo $_GET['id_admin'] ?>">Quản lý blog</a></li>
		</ul>
	</div>
		<?php
			//include("views/menu.php");
			include("controllers/content.php");
		 ?>
	</div>
	<div class="col-md-2" id="right"></div>
</body>
</html>
