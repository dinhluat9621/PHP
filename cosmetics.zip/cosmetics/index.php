<!DOCTYPE html>
<html>
<head>
	<title>Gumiho Cosmetics</title>
	<link rel="stylesheet" href="views/css/cosmetic.css">
	<link rel="stylesheet" href="views/css/dangnhap.css">
	<link rel="stylesheet" href="views/css/bootstrap.min.css">
 	<link rel="stylesheet" href="views/css/bootstrap-theme.min.css">
  	<script type="views/js/jquery-3.2.0.min.js"></script>
</head>
<body>
	<?php
		include('views/TrangChu.php');  
	?>
</body>
</html>