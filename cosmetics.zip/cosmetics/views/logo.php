
<!-- Logo content -->
  <div class="logo_content">
    <a href="views/admin.php?xem=trangchu&id_admin=<?php echo $_GET['id_admin'] ?>"><img src="views/image/gumiho.png" id="logo"></a>
    <div class="right_logo">
      <div>
        <p>
          <span style="font-family:arial,helvetica,sans-serif">
            <span style="font-size:16px">
              <strong>MIỄN PHÍ GIAO HÀNG VỚI HÓA ĐƠN TỪ&nbsp;400.000 VNĐ TẠI&nbsp;TP HỒ CHÍ MINH</strong>
            </span>
          </span>
        </p>

        <p>
            <span style="font-family:arial,helvetica,sans-serif">
              <span style="font-size:16px">
                <strong>MIỄN PHÍ GIAO HÀNG VỚI HÓA ĐƠN TỪ 600.000 VNĐ ĐỐI VỚI CÁC KHU VỰC KHÁC</strong>
              </span>
            </span>
        </p>
      </div>
    </div>
  </div>
