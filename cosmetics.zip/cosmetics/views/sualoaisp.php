<?php
	include("models/config.php");
	if(!isset($_GET['id_admin'])){
	      header('location:DangNhap.php');
	    }
	$sql="select * from loaisanpham where id_loaisp=$_GET[id]";
	$rs=mysql_query($sql);
	$dong=mysql_fetch_array($rs);
	/*models/sanpham.php?id=<?php echo $dong['ID_SanPham'] ?>*/
?>
<form action="models/loaisp.php?id=<?php echo $dong['ID_LoaiSP'] ?>" method="post" enctype="multipart/form-data"> 
<table width="1674" id="tab_2">
		<tr>
			<th width="347"></th>
			<th width="586"></th>
			<th width="558"></th>
            <th width="163"></th>
		</tr>
		<tr>
			<td>Mã loại sản phẩm</td>
			<td>Tên loại sản phẩm</td>
			<td>Tên danh mục</td>
		</tr>
		<tr>
			<td><input type="Text" name="id_loaisp" id="id_loaisp" value="<?php echo $dong['ID_LoaiSP'] ?>"></td>
			<td><input type="Text" name="tenloaisp" id="tenloaisp" value="<?php echo $dong['TenLoaiSP'] ?>"></td>
			<?php
				$sql_dm="select * from danhmucsanpham";
				$rs_dm=mysql_query($sql_dm);  
			?>
			<td><select name="tendm">
			<?php
				while ($dong_dm=mysql_fetch_array($rs_dm)) {
				  	if($dong['TenDanhMuc']==$dong_dm['TenDanhMuc']){ 
			?>
						<option selected="selected" value="<?php echo $dong_dm['ID_DanhMuc'] ?>"><?php echo $dong_dm['TenDanhMuc'] ?></option>
			<?php
					}
					else{  
			?>
						<option value="<?php echo $dong_dm['ID_DanhMuc'] ?>"><?php echo $dong_dm['TenDanhMuc'] ?></option>
			<?php
						}
				}  
			?>
		</tr>
		<tr>
			<td><p></p></td>
		</tr>
			<td><input type="submit" name="sua" id="sua" value="Sửa"></td>
		</tr>
</table>
<div><p style="font-size: 21px; font-weight: bold; text-align: center; text-indent: 350px;">Danh sách loại sản phẩm</p></div>
</form>
<div><p></p></div>