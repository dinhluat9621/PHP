<form action="models/taikhoan.php" method="post" enctype="multipart/form-data">
<table style="width: 1100px;">
		<tr>
			<th width="347"></th>
			<th width="586"></th>
			<th width="558"></th>
            <th width="163"></th>
		</tr>
		<tr>
			<td>Mã tài khoản</td>
			<td>Tên đăng nhập</td>
			<td>Mật khẩu</td>
		</tr>
		<tr>
			<td><input type="Text" name="id_tk" id="id_tk" cols="30" rows="1"></td>
			<td><input type="Text" name="username" id="username" cols="30" rows="1"></td>
			<td><input type="Text" name="password" id="password" cols="30" rows="1"></td>
		</tr>
		<tr>
			<td><p></p></td>
			<td><p></p></td>
			<td><p></p></td>
		</tr>
		<tr>
			<td><button name="them" value="Thêm">Thêm</button></td>
		</tr>
</table>
<div><p style="font-size: 21px; font-weight: bold; text-align: center; text-indent: 450px;">Danh sách tài khoản</p></div>
</form>
