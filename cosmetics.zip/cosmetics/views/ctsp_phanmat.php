<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Phấn mắt | Gumiho</title>
	<link rel="stylesheet" href="css/cosmetic.css">
	<link rel="stylesheet" href="css/dangnhap.css">
	<link rel="stylesheet" href="css/banchay.css">
	<link rel="stylesheet" href="css/mat.css">
	<link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/price-range.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
	<link href="css/main.css" rel="stylesheet">
	<link href="css/responsive.css" rel="stylesheet">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<script type="text/javascript" src="js/jquery-3.2.0.min.js"></script>
	<script type="text/javascript" src="js/verticalmenu.js"></script>
</head>
<body>
	<?php
		include("../models/config.php");
		$sql="select * from chitietsanpham where id_sanpham='$_GET[id]'";
		$rs=mysql_query($sql);
		$row_chitiet=mysql_fetch_array($rs);
		$id_sp=$row_chitiet['ID_SanPham'];
		$sql_sp="select * from sanpham where id_sanpham='$_GET[id]'";
		$rs_sp=mysql_query($sql_sp);
		$row_sp=mysql_fetch_array($rs_sp);
	?>
	<div id="navigation">
		<ul>
			<li><a href="#">BLOG LÀM ĐẸP</a></li>
			<li><a href="#">THÔNG TIN SƯ KIÊN</a></li>
			<li><a href="LienHe.php">LIÊN HỆ</a></li>
			<li><a href="#">TUYỂN DỤNG</a></li>
			<li><a href="giohang.php">GIỎ HÀNG</a></li>
			<li class="sign" style="border-style:none;">
	        <form action="models/timkiem.php" method="post" accept-charset="utf-8" enctype="multipart/form-data">
	          <input type="submit" id="searchbtn" name="search" value="Search" style="border-style: solid; color: white; background: #111;); height: 30px; width: 50px;">
	        </form>
	      </li>
			<li class="sign"><input type="search" placeholder="Tìm kiếm..."></li>
			<?php
				if(isset($_GET['id_kh'])){
			?>
			<li class="sign"><a href="../index.php">Đăng xuất</a></li>
			<?php
				}
				else{  
			?>
			<li class="sign"><a href="DangNhap.php">Đăng nhập</a></li>
			<?php
				}  
			?>
		</ul>
	</div>

	<!-- Left -->
		<div class="col-md-2" id="left"></div>

	<!-- Content -->
		<div class="col-md-8" id="content">
      		<!-- Logo content -->
	        <div class="logo_content">
	          <a href="../index.php"><img src="image/gumiho.png" id="logo"></a>
	          <div class="right_logo">
	            <div>
	              <p>
	                <span style="font-family:arial,helvetica,sans-serif">
	                  <span style="font-size:16px">
	                    <strong>MIỄN PHÍ GIAO HÀNG VỚI HÓA ĐƠN TỪ&nbsp;400.000 VNĐ TẠI&nbsp;TP HỒ CHÍ MINH</strong>
	                  </span>
	                </span>
	              </p>

	              <p>
	                  <span style="font-family:arial,helvetica,sans-serif">
	                    <span style="font-size:16px">
	                      <strong>MIỄN PHÍ GIAO HÀNG VỚI HÓA ĐƠN TỪ 600.000 VNĐ ĐỐI VỚI CÁC KHU VỰC KHÁC</strong>
	                    </span>
	                  </span>
	              </p>
	            </div>
	          </div>
	        </div>
      		<!-- Logo content -->
			<div id="menu"><br>
			  	<ul>
			  		<li><a href="#">MỚI</a></li>
			  		<li><a href="BanChay.php">BÁN CHẠY</a></li>
				    <li><a href="#">MẮT</a>
				      <ul class="submenu">
				        <li><a href="PhanMat.php">Phấn mắt</a></li>
				        <li><a href="KeMat.php">Kẻ mắt</a></li>
				        <li><a href="Mascara.php">Mascara</a></li>
				        <li><a href="ChanMay.php">Chân mày</a></li>
				        <li><a href="LongMiGia.php">Lông mi giả</a></li>
		                <li><a href="PaletteChoMat.php">Pallette cho mắt</a></li>
		                <li><a href="CoMat.php">Cọ mắt</a></li>
		                <li><a href="DuongDaMat.php">Dưỡng da mắt</a></li>
				      </ul>
				    </li>
					<li><a href="#">MÔI</a>
			            <ul class="submenu">
			              <li><a href="#">Son bóng</a></li>
			              <li><a href="#">Son môi</a></li>
			              <li><a href="#">Kẻ môi</a></li>
			              <li><a href="#">Dưỡng môi</a></li>
			              <li><a href="#">Cọ môi</a></li>  
			            </ul>
          			</li>
					<li><a href="#">MẶT</a>
			            <ul class="submenu">
			              <li><a href="#">Dưỡng da</a></li>
			              <li><a href="#">Kem nền</a></li>
			              <li><a href="#">Che khuyết điểm</a></li>
			              <li><a href="#">Phấn</a></li>
			              <li><a href="#">Má hồng</a></li>
			              <li><a href="#">Pallette cho mặt</a></li>
			              <li><a href="#">Tạo khối</a></li>
			              <li><a href="#">Cọ</a></li>
			              <li><a href="#">Tẩy trang</a></li>
			              <li><a href="#">Kem lót</a></li>
			              <li><a href="#">Kem dưỡng trang điểm</a></li>
			              <li><a href="#">Trang điểm ánh nhũ</a></li>
			              <li><a href="#">Dụng cụ</a></li>  
			            </ul>
          			</li>
					<li><a href="#">MÓNG</a>
			            <ul class="submenu">
			              <li><a href="#">Sơn móng tay</a></li>
			              <li><a href="#">Sản phẩm cho móng</a></li>
			              <li><a href="#">Dụng cụ làm móng</a></li>
			            </ul>
          			</li>
					<li><a href="#">DỤNG CỤ</a>
			            <ul class="submenu">
			              <li><a href="#">Bộ cọ</a></li>
			              <li><a href="#">Cọ lẻ</a></li>
			              <li><a href="#">Bông phấn</a></li>
			              <li><a href="#">Phấn</a></li>
			              <li><a href="#">Phụ kiện trang điểm</a></li>
			              <li><a href="#">Hộp đựng</a></li>
			              <li><a href="#">Bấm mi</a></li>
			              <li><a href="#">Gương</a></li>
			              <li><a href="#">Đồ chuốt</a></li>
			              <li><a href="#">Nhíp</a></li>
			              <li><a href="#">Vẽ chân mày</a></li>  
			            </ul>
          			</li>
			  	</ul>
			</div>
			
			<div><p></p></div>
			<div class="sub-menu">
			  	<ul class="">
			  		<li>
			  			<a href="TrangChu.php">Trang chủ</a>
		  			</li>
					<li>
						<a href="">Mắt</a>
					</li>
					<li><a href="PhanMat.php">Phấn mắt</a></li>
					<li><a href=""><?php echo $row_sp['TenSanPham'] ?></a></li>
			  	</ul>
			</div>

		
			<!--<section style="float: left; width: 900px;">
				<table>
					<tr>
						<th></th>
						<th></th>
					</tr>
					<tr>
						<td><img src="image/1.png" style="width: 500px; height: 400px; border: 1px solid gray;"></td>
						<td style="text-indent: 100px;">
							<p>Tên sản phẩm</p>
							<p>Giá</p>
							<p>Tình trạng</p>
							<p><input type="text" name="sl">Số lượng</p>

						</td>
					</tr>
				</table>
			</section>-->
			
			
			<div class="product-details"><!--product-details-->
				<div class="col-sm-5">
					<div class="view-product">
						<img src="image/<?php echo $row_chitiet['Anh'] ?>" alt="" />
					</div>
					<div id="similar-product" class="carousel slide" data-ride="carousel">
						
						  <!-- Wrapper for slides -->
						    <div class="carousel-inner">
								<div class="item active">
								  <a href=""><img src="image/product-details/similar1.jpg" alt=""></a>
								  <a href=""><img src="image/product-details/similar2.jpg" alt=""></a>
								  <a href=""><img src="image/product-details/similar3.jpg" alt=""></a>
								</div>
								
							</div>

						  <!-- Controls 
						  <a class="left item-control" href="#similar-product" data-slide="prev">
							<i style="background-color: #111;"><img src="image/previous.png" style="margin-top: 0px; margin-bottom: 3px; margin-left: -4px; margin-right: 4px;"></i>
						  </a>
						  <a class="right item-control" href="#similar-product" data-slide="next">
							<i style="background-color: #111;"><img src="image/next.png" style="margin-top: 0px; margin-bottom: 3px; margin-left: -4px; margin-right: 4px;"></i>
						  </a>-->
					</div>
				</div>
				<div class="col-sm-7">
					<div class="product-information"><!--/product-information-->
						<h2><?php echo $row_sp['TenSanPham'] ?></h2>
						<span>
							<span style="color: #ff1a75; font-weight: normal; font-size: 30px;"><?php echo number_format($row_chitiet['Gia'] , 0)?> VNĐ</span><br>
							<label>Số lượng trong kho:</label>
							<input readonly="true" type="text" name="soluong" value="<?php echo $row_chitiet['SoLuong'] ?>" />
						</span>
						<p><b>Tình trạng:</b>  <?php echo $row_chitiet['TinhTrang'] ?></p><br>
						<?php
							if(isset($_GET['id_kh'])){  
						?>
						<a href="giohang.php?xem=giohang&add=<?php echo $row_chitiet['ID_SanPham'] ?>&id_kh=<?php echo $_GET['id_kh'] ?>"><button type="submit" name="them" class="btn btn-fefault cart" style="background-color: #ff1a75;">
							Thêm vào giỏ
						</button></a>
						<?php
							}
							else{  
						?>
						<a href="DangNhap.php"><button type="submit" name="them" class="btn btn-fefault cart" style="background-color: #ff1a75;">
							Thêm vào giỏ
						</button></a>
						<?php
							}  
						?>
					</div><!--/product-information-->
				</div>
			</div><!--/product-details-->

			<!--recommended_items
			<div class="recommended_items">
				<h2 class="title text-center" style="color: black;">recommended items</h2>
				
				<div id="recommended-item-carousel" class="carousel slide" data-ride="carousel">
					<div class="carousel-inner">
						<div class="item active">
							<div class="col-sm-4">
								<div class="product-image-wrapper">
									<div class="single-products">
										<div class="productinfo text-center">
											<img src="image/home/recommend3.jpg" alt="" />
											<h2>$56</h2>
											<p>Easy Polo Black Edition</p>
											<button type="button" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</button>
										</div>
									</div>
								</div>
							</div>
							<div class="col-sm-4">
								<div class="product-image-wrapper">
									<div class="single-products">
										<div class="productinfo text-center">
											<img src="image/home/recommend3.jpg" alt="" />
											<h2>$56</h2>
											<p>Easy Polo Black Edition</p>
											<button type="button" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</button>
										</div>
									</div>
								</div>
							</div>
							<div class="col-sm-4">
								<div class="product-image-wrapper">
									<div class="single-products">
										<div class="productinfo text-center">
											<img src="image/home/recommend3.jpg" alt="" />
											<h2>$56</h2>
											<p>Easy Polo Black Edition</p>
											<button type="button" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</button>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="item">	
							<div class="col-sm-4">
								<div class="product-image-wrapper">
									<div class="single-products">
										<div class="productinfo text-center">
											<img src="image/home/recommend2.jpg" alt="" />
											<h2>$56</h2>
											<p>Easy Polo Black Edition</p>
											<button type="button" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</button>
										</div>
									</div>
								</div>
							</div>
							<div class="col-sm-4">
								<div class="product-image-wrapper">
									<div class="single-products">
										<div class="productinfo text-center">
											<img src="image/home/recommend2.jpg" alt="" />
											<h2>$56</h2>
											<p>Easy Polo Black Edition</p>
											<button type="button" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</button>
										</div>
									</div>
								</div>
							</div>
							<div class="col-sm-4">
								<div class="product-image-wrapper">
									<div class="single-products">
										<div class="productinfo text-center">
											<img src="image/home/recommend3.jpg" alt="" />
											<h2>$56</h2>
											<p>Easy Polo Black Edition</p>
											<button type="button" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</button>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					 <a class="left recommended-item-control" href="#recommended-item-carousel" data-slide="prev">
						<i style="background-color: #111;"><img src="image/previous.png" style="margin-top: 0px; margin-bottom: 3px; margin-left: -4px; margin-right: 4px;"></i>
					  </a>
					  <a class="right recommended-item-control" href="#recommended-item-carousel" data-slide="next">
						<i style="background-color: #111;"><img src="image/next.png" style="margin-top: 0px; margin-bottom: 3px; margin-left: -4px; margin-right: 4px;"></i>
					  </a>			
				</div>
			</div>-->

			<section>
				<div>
					<p></p><br>
				</div>
			</section>
			<section class="about-sect">
				<div>
				  	<table id="table_3">
					    <tr>	
					      <th><p></p>Tại sao lại chọn chúng tôi?</th>
					    </tr>
					    <tr>
					    	<td>
					    		<p></p>
					    	</td>
					    </tr>
					    <tr>
					    	<td>gumiho cosmetics là nhãn hiệu mỹ phẩm không thể thiếu cho nhu cầu trang 
              					điểm và làm đẹp mỗi ngày của bạn. Tại gumiho, chúng tôi cung cấp những 
              					sản phẩm chất lượng với giá cả phải chăng đem lại nét rạng rỡ tự nhiên 
	              				cho gương mặt với sự đa dạng về chủng loại sản phẩm, son bóng quyến rũ 
	              				nhiều tông màu với nhiều kiểu dáng khác nhau cũng như son môi dưỡng 
	              				ẩm chuyên sâu đem lại màu sắc tươi tắn và lâu phai suốt cả ngày.
					    	</td>
					    </tr>
			            <tr>
			              <td><p></p></td>
			            </tr>
			            <tr>
			              <td>Bên cạnh đó, dòng sản phẩm trang điểm khoáng chất của gumiho an toàn không chứa màu 
	          				nhuộm hóa học và chất bảo quản giúp nuôi dưỡng làn da của bạn sáng bóng, khỏe mạnh hơn.
			              </td>
			            </tr>
					    <tr>
					    	<td>
					    		<p></p>
					    	</td>
					    </tr>
				    </table>
				</div>
				
	      		<p id="p">a</p>
				<div>
					<p class="font1"><br>Copyright &copy 2017 Gumiho Cosmetics VN. Powered by UIT</p>
				</div>
			</section>
			<div>
		        <table id="table_5">
		          <th><img src="image/peta.png" id="image"></th>
		          <th><img src="image/logo_client.png" id="image"></th>
		          <th><img src="image/paypal.png" id="image"></th>
		        </table>
			</div>
		</div>

	<!-- Right -->
		<div class="col-md-2" id="right"></div>

	<!-- Footer -->
  		<div class="col-md-12" id="footer" style="height: 200px; background: gray;">
  			<table id="table_4">	
  					<tr>
  						<p></p>
  					</tr>
  					<tr>
  						<th id="column">SẢN PHẨM MỚI</th>
  						<th id="column">MẮT<p></p></th>
  						<th id="column">MÔI</th>
  						<th id="column">MẶT</th>
  						<th id="column">MÓNG</th>
  					</tr>
  					<tr>
  						<td>BÁN CHẠY</td>
  						<td>Phấn mắt</td>
  						<td>Son bóng</td>
  						<td>Dưỡng da</td>
  						<td>Sơn móng tay</td>
  					</tr>
  					<tr>
  						<td>BLOG LÀM ĐẸP</td>
  						<td>Kẻ mắt</td>
  						<td>Son môi</td>
  						<td>Kem nền</td>
  						<td>Sản phẩm cho móng</td>
  					</tr>
  					<tr>
  						<td></td>
  						<td>Mascara</td>
  						<td>Cọ môi</td>
  						<td>Che khuyết điểm</td>
  						<td>Dụng cụ làm móng</td>

  					</tr>
  					<tr>
  						<td></td>
  						<td>Cọ mắt</td>
  						<td></td>
  						<td>Phấn & Má hồng</td>
  						<td></td>
  					</tr>
  					<tr>
  						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  					</tr>
  					<tr>
  						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  					</tr>
  					<tr>
  						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  					</tr>
  					<tr>
  						<td></td>
  						<td></td>
  						<td></td> 
  						<td></td>
  					</tr>
  					<tr>
  						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  					</tr>
  					<tr>
  						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  					</tr>
  					<tr>
  						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  					</tr>
  					<tr>
  						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  					</tr>
  					<tr>
						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  					</tr>
  			</table>
  		</div>
	<!-- Footer -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script> 
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.js"></script>
<script src="js/price-range.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.prettyPhoto.js"></script>
<script src="js/main.js"></script>
</body>
</html>