<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Đăng ký</title>
	<link rel="stylesheet" href="css/cosmetic.css">
	<link rel="stylesheet" href="css/dangky.css">
	<link rel="stylesheet" href="css/datepicker.css"/>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<link rel="stylesheet prefetch" href="http://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<script src="js/cosmetics.js"></script>
	
<script type="text/javascript">
	//Google Analytics
	  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

	  ga('create', 'UA-30316415-1', 'sothichweb.com');
	  ga('send', 'pageview');
</script>
</head>

</head>
<body>
 
	<div id="navigation">
		<ul>
			<li><a href="#">BLOG LÀM ĐẸP</a></li>
			<li><a href="#">THÔNG TIN SƯ KIÊN</a></li>
			<li><a href="LienHe.php">LIÊN HỆ</a></li>
			<li><a href="#">TUYỂN DỤNG</a></li>
			<li><a href="giohang.php">GIỎ HÀNG</a></li>
			<li class="sign"><input type="search" placeholder="Tìm kiếm..."></li>
			<li class="sign"><a href="DangNhap.php">Đăng nhập</a></li>
		</ul>
	</div>

	<!-- Left -->
		<div class="col-md-2" id="left"></div>

	<!-- Content -->
		<div class="col-md-8" id="content">
      <!-- Logo content -->
        <div class="logo_content">
          <a href="TrangChu.php"><img src="image/gumiho.png" id="logo"></a>
          <div class="right_logo">
            <div>
              <p>
                <span style="font-family:arial,helvetica,sans-serif">
                  <span style="font-size:16px">
                    <strong>MIỄN PHÍ GIAO HÀNG VỚI HÓA ĐƠN TỪ&nbsp;400.000 VNĐ TẠI&nbsp;TP HỒ CHÍ MINH</strong>
                  </span>
                </span>
              </p>

              <p>
                  <span style="font-family:arial,helvetica,sans-serif">
                    <span style="font-size:16px">
                      <strong>MIỄN PHÍ GIAO HÀNG VỚI HÓA ĐƠN TỪ 600.000 VNĐ ĐỐI VỚI CÁC KHU VỰC KHÁC</strong>
                    </span>
                  </span>
              </p>
            </div>
          </div>
        </div>
      <!-- Logo content -->
			<div id="menu">
        <br>
			  	<ul>
            <li><a href="views/BanChay.php">BÁN CHẠY</a></li>
				    <li><a href="#">MẮT</a>
				      <ul class="submenu">
				        <li><a href="views/PhanMat.php">Phấn mắt</a></li>
				        <li><a href="views/KeMat.php">Kẻ mắt</a></li>
				        <li><a href="views/Mascara.php">Mascara</a></li>
                <li><a href="views/CoMat.php">Cọ mắt</a></li>
				      </ul>
				    </li>
					<li><a href="#">MÔI</a>
            <ul class="submenu">
              <li><a href="#">Son bóng</a></li>
              <li><a href="#">Son môi</a></li>
              <li><a href="#">Cọ môi</a></li>  
            </ul>
          </li>
					<li><a href="#">MẶT</a>
            <ul class="submenu">
              <li><a href="#">Dưỡng da</a></li>
              <li><a href="#">Kem nền</a></li>
              <li><a href="#">Che khuyết điểm</a></li>
              <li><a href="#">Phấn & Má hồng</a></li>
            </ul>
          </li>
					<li><a href="#">MÓNG</a>
            <ul class="submenu">
              <li><a href="#">Sơn móng</a></li>
              <li><a href="#">Dụng cụ</a></li>
            </ul>
          </li>
					
			  	</ul>
			</div>
			<div class="sub-menu">
			  	<ul>
			  		<li><a href="#">Trang chủ</a></li>
					<li><a href="#">Đăng ký</a></li>
			  	</ul>
			</div>
			<section style="width: 600px;" class="col-md-5">
			<article style="text-indent: 10px; float: right; border: 1px solid white;" class="col-md-7" >
				<div id="register">
						<h4 style="text-indent: 100px; font-weight: bold;">Đăng ký thành viên</h4><br>
						<form method="post" action="#" name="register" enctype="multipart/form-data">
			            	<p>
								<label id="label" for="email">EMAIL(*)</label>
								<input class="text" type="text" name="email" id="email" /></p>
							<p>
								<label id="label" for="matkhau">MẬT KHẨU(*)</label>
								<input class="text" type="password" name="matkhau" id="matkhau" /></p>
							<p>
								<label id="label" for="xnmatkhau">NHẬP LẠI MẬT KHẨU(*)</label>
								<input class="text" type="password" name="xnmatkhau" id="xnmatkhau" /></p>

							<p><label id="label" for="hoten">HỌ TÊN(*)</label>
								<input class="text" type="text" name="hoten" id="hoten" /></p>

							<p><label id="label" for="sdt">SỐ ĐIỆN THOẠI(*)</label>
								<input class="text" type="text" name="sdt" id="sdt" /></p>
			                
							<p style="text-indent: 150px;"><input style="color: white; background: #111; font-size: 12px;" type="submit" name="dangky" id="dangky" value="Đăng ký" /></p>
						</form>
				</div><!-- end #register -->
			</article>
			</section>
			<table id="sub-table">
				<th colspan="" rowspan="" headers="" scope=""></th>
			</table>
			<div>
			  	<table id="table_3">
				    <tr>	
				      <th><p></p>Tại sao lại chọn chúng tôi?</th>
				    </tr>
				    <tr>
				    	<td>
				    		<p></p>
				    	</td>
				    </tr>
				    <tr>
				    	<td> gumiho cosmetics là nhãn hiệu mỹ phẩm không thể thiếu cho nhu cầu trang 
              điểm và làm đẹp mỗi ngày của bạn. Tại gumiho, chúng tôi cung cấp những 
              sản phẩm chất lượng với giá cả phải chăng đem lại nét rạng rỡ tự nhiên 
              cho gương mặt với sự đa dạng về chủng loại sản phẩm, son bóng quyến rũ 
              nhiều tông màu với nhiều kiểu dáng khác nhau cũng như son môi dưỡng 
              ẩm chuyên sâu đem lại màu sắc tươi tắn và lâu phai suốt cả ngày.
				    	</td>
				    </tr>
            <tr>
              <td><p></p></td>
            </tr>
            <tr>
              <td>Bên cạnh đó, dòng sản phẩm trang điểm khoáng chất của gumiho an toàn không chứa màu 
              nhuộm hóa học và chất bảo quản giúp nuôi dưỡng làn da của bạn sáng bóng, khỏe mạnh hơn.
              </td>
            </tr>
				    <tr>
				    	<td>
				    		<p></p>
				    	</td>
				    </tr>
			    </table>
			</div>
      <p id="p">a</p>
			<div>
				<p class="font1"><br>Copyright &copy 2017 Gumiho Cosmetics VN. Powered by UIT</p>
			</div>
			<div>
        <table id="table_5">
          <th><img src="image/peta.png" id="image"></th>
          <th><img src="image/logo_client.png" id="image"></th>
          <th><img src="image/paypal.png" id="image"></th>
        </table>
			</div>
		</div>

	<!-- Right -->
		<div class="col-md-2" id="right"></div>

	<!-- Footer -->
  		<div class="col-md-12" id="footer" style="height: 160px; background-color: gray;" >
  			<table id="table_4">	
  					<tr>
  						<p></p>
  					</tr>
  					<tr>
  						<th id="column">SẢN PHẨM MỚI</th>
  						<th id="column">MẮT<p></p></th>
  						<th id="column">MÔI</th>
  						<th id="column">MẶT</th>
  						<th id="column">MÓNG</th>
  					</tr>
  					<tr>
  						<td>BÁN CHẠY</td>
  						<td>Phấn mắt</td>
  						<td>Son bóng</td>
  						<td>Dưỡng da</td>
  						<td>Sơn móng tay</td>
  					</tr>
  					<tr>
  						<td>BLOG LÀM ĐẸP</td>
  						<td>Kẻ mắt</td>
  						<td>Son môi</td>
  						<td>Kem nền</td>
  						<td>Sản phẩm cho móng</td>
  					</tr>
  					<tr>
  						<td></td>
  						<td>Mascara</td>
  						<td>Cọ môi</td>
  						<td>Che khuyết điểm</td>
  						<td>Dụng cụ</td>

  					</tr>
  					<tr>
  						<td></td>
  						<td>Cọ mắt</td>
  						<td></td>
  						<td>Phấn & Má hồng</td>
  						<td></td>
  					</tr>
  					<tr>
  						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  					</tr>
  					<tr>
  						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  					</tr>
  					<tr>
  						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  					</tr>
  					<tr>
  						<td></td>
  						<td></td>
  						<td></td> 
  						<td></td>
  					</tr>
  					<tr>
  						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  					</tr>
  					<tr>
  						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  					</tr>
  					<tr>
  						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  					</tr>
  					<tr>
  						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  					</tr>
  					<tr>
						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  					</tr>
  			</table>
  		</div>
    <!-- Footer -->

</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
</html>