<?php
	include("models/config.php");
    $sql="select * from admin where id=$_GET[id_admin]";
    $rs=mysql_query($sql);
    $row=mysql_fetch_array($rs);
?>
<div id="menu">
	<ul>
		<li style="width: 100px;"><a href="views/admin.php?xem=trangchu&id_admin=<?php echo $_GET['id_admin'] ?>">Trang chủ</a></li>
		<li style="width: 150px;"><a href="QuanLySanPham.php?quanly=quanlysp&ac=them&id_admin=<?php echo $_GET['id_admin'] ?>">Quản lý sản phẩm</a></li>
		<li style="width: 140px;"><a href="">Quản lý tài khoản</a></li>
		<li style="width: 140px;"><a href="">Quản lý thành viên</a></li>
		<li style="width: 140px;"><a href="">Quản lý hóa đơn</a></li>
		<li style="width: 140px;"><a href="">Quản lý cthd</a></li>
	</ul>
</div>