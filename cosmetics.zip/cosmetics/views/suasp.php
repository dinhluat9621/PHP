<?php
	include("models/config.php");
	if(!isset($_GET['id_admin'])){
	      header('location:DangNhap.php');
	    }
	$sql="select * from sanpham where id_sanpham=$_GET[id]";
	$rs=mysql_query($sql);
	$dong=mysql_fetch_array($rs);
	
	/*models/sanpham.php?id=<?php echo $dong['ID_SanPham'] ?>*/
?>
<form action="models/sanpham.php?id=<?php echo $dong['ID_SanPham']?>&id_admin=<?php echo $_GET['id_admin'] ?>" method="post" enctype="multipart/form-data"> 
<table width="1674" id="tab_2">
		<tr>
			<th width="347"></th>
			<th width="586"></th>
			<th width="558"></th>
            <th width="163"></th>
		</tr>
		<tr>
			<td>Mã sản phẩm</td>
			<td>Loại sản phẩm</td>
			<td>Tên sản phẩm</td>
		</tr>
		<tr>
			<td><input type="Text" name="id_sp" id="id_sp" value="<?php echo $dong['ID_SanPham'] ?>"></td>
			<?php
				$sql_lsp="select * from loaisanpham";
				$rs_lsp=mysql_query($sql_lsp);  
			?>
			<td><select name="loaisp">
			<?php
				while ($dong_lsp=mysql_fetch_array($rs_lsp)) {
				  	if($dong['ID_LoaiSP']==$dong_lsp['ID_LoaiSP']){ 
			?>
						<option selected="selected" value="<?php echo $dong_lsp['ID_LoaiSP'] ?>"><?php echo $dong_lsp['TenLoaiSP'] ?></option>
			<?php
					}
					else{  
			?>
						<option value="<?php echo $dong_lsp['ID_LoaiSP'] ?>"><?php echo $dong_lsp['TenLoaiSP'] ?></option>
			<?php
						}
				}  
			?>
			<td><input type="Text" name="tensp" id="tensp" value="<?php echo $dong['TenSanPham'] ?>"></td>
		</tr>
		<tr>
			<td><p></p></td>
			<td><p></p></td>
			<td><p></p></td>
		</tr>
		<tr>	
			<td>Thông tin sản phẩm</td>
			<td>Hướng dẫn sử dụng</td>
		</tr>
		<tr>
			<td><textarea type="Text" name="ttsp" id="ttsp" cols="30" rows="10" value=""><?php echo $dong['ThongTinSP'] ?></textarea></td>
			<td><textarea type="Text" name="hdsd" id="hdsd" cols="30" rows="10" value=""><?php echo $dong['HuongDanSD'] ?></textarea></td>
		</tr>
		<tr>
			<td><p></p></td>
		</tr>
		<tr>
			<td></a><input type="submit" name="sua" id="sua" value="Sửa"></td>
		</tr>
</table>
<div><p style="font-size: 21px; font-weight: bold; text-align: center; text-indent: 450px;">Danh sách sản phẩm</p></div>
</form>
<div><p></p></div>