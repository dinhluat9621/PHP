
<form action="models/thanhvien.php" method="post" enctype="multipart/form-data">
<table style="width: 1100px;">
		<tr>
			<th width="347"></th>
			<th width="586"></th>
			<th width="558"></th>
            <th width="163"></th>
		</tr>
		<tr>
			<td>Mã thành viên</td>
			<td>Họ tên</td>
			<td>Địa chỉ</td>
		</tr>
		<tr>
			<td><input type="Text" name="id_tv" id="id_tv" cols="30" rows="1"></td>
			<td><input type="Text" name="hoten" id="hoten" cols="30" rows="1"></td>
			<td><input type="Text" name="diachi" id="diachi" cols="30" rows="1"></td>
		</tr>
		<tr>
			<td>Quận huyện</td>
			<td>Tỉnh</td>
			<td>Số điện thoại</td>
		</tr>
		<tr>
			<td><input type="Text" name="quan_huyen" id="quan_huyen" cols="30" rows="1"></td>
			<td><input type="Text" name="tinh" id="tinh" cols="30" rows="1"></td>
			<td><input type="Text" name="sodienthoai" id="sodienthoai" cols="30" rows="1"></td>
		</tr>
		<tr>
			<td>Email</td>
			<td>Mật khẩu</td>
		</tr>
		<tr>
			<td><input type="Text" name="email" id="email" cols="30" rows="1"></td>
			<td><input type="Text" name="matkhau" id="matkhau" cols="30" rows="1"></td>
		</tr>
		<tr>
			<td><p></p></td>
			<td><p></p></td>
			<td><p></p></td>
		</tr>
		<tr>
			<td><button name="them" value="Thêm">Thêm</button></td>
		</tr>
</table>
<div><p style="font-size: 21px; font-weight: bold; text-align: center; text-indent: 450px;">Danh sách thành viên</p></div>
</form>