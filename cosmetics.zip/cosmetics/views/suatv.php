<?php
	$sql="select * from khachhang where id=$_GET[id]";
	$rs=mysqli_query($conn,$sql);
	$dong=mysqli_fetch_array($rs);
	/*models/taikhoan.php?id=<?php echo $dong['ID_SanPham'] ?>*/
?>
<form action="models/thanhvien.php?id=<?php echo $dong['ID'] ?>" method="post" enctype="multipart/form-data"> 
<table width="1674" id="tab_2">
		<tr>
			<th width="347"></th>
			<th width="586"></th>
			<th width="558"></th>
            <th width="163"></th>
		</tr>
		<tr>
			<td>Mã thành viên</td>
			<td>Họ tên</td>
			<td>Địa chỉ</td>
		</tr>
		<tr>
			<td><input type="Text" name="id_tv" id="id_tv" cols="30" rows="1" value=""><?php echo $dong['ID_kh'] ?></td>
			<td><input type="Text" name="hoten" id="hoten" cols="30" rows="1" value=""><?php echo $dong['hoten'] ?></td>
			<td><input type="Text" name="diachi" id="diachi" cols="30" rows="1" value=""><?php echo $dong['diachi'] ?></td>
		</tr>
		<tr>
			<td>Quận huyện</td>
			<td>Tỉnh</td>
			<td>Số điện thoại</td>
		</tr>
		<tr>
			<td><input type="Text" name="quan_huyen" id="quan_huyen" cols="30" rows="1" value=""><?php echo $dong['quan_huyen'] ?></td>
			<td><input type="Text" name="tinh" id="tinh" cols="30" rows="1" value=""><?php echo $dong['tinh'] ?></td>
			<td><input type="Text" name="sodienthoai" id="sodienthoai" cols="30" rows="1" value=""><?php echo $dong['sodienthoai'] ?></td>
		</tr>
		<tr>
			<td>Email</td>
			<td>Mật khẩu</td>
		</tr>
		<tr>
			<td><input type="Text" name="email" id="email" cols="30" rows="1" value=""><?php echo $dong['email'] ?></td>
			<td><input type="Text" name="matkhau" id="matkhau" cols="30" rows="1" value=""><?php echo $dong['matkhau'] ?></td>
		</tr>
		<tr>
			<td><p></p></td>
			<td><p></p></td>
			<td><p></p></td>
		</tr>
		<tr>
			<td><input type="submit" name="sua" id="sua" value="Sửa"></td>
		</tr>
</table>
<div><p style="font-size: 21px; font-weight: bold; text-align: center; text-indent: 450px;">Danh sách thành viên</p></div>
</form>
<div><p></p></div>