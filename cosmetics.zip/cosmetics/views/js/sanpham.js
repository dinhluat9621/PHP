function() {
  $("#review").css({
    'height': 'auto',
    'overflow': 'visible',
    'padding': ''
  }).slideUp();
  var id = $(this).attr('href');
  if ($(id).is(':hidden') || id == '#review') {
    $('.detail_pro ul.tabs li').removeClass('active_tabs');
    $('.content_tabs .details').hide();
    $(id).fadeIn();
    $(this).parent().addClass('active_tabs');
  }
  return false;
}

