function Change(trang) 
{
	var xmlhttp = new XMLHttpRequest();
	var ARRAY;

	xmlhttp.onreadystatechange = function() 
	{
		if (xmlhttp.readyState == 4 && xmlhttp.status == 200) 
		{
			ARRAY = xmlhttp.responseText.split("|");
			document.getElementById("LIST").innerHTML = ARRAY[0];
			document.getElementById("PAGI").innerHTML = ARRAY[1];
		}
	}
	xmlhttp.open("GET", "../../models/PAGE.php?page=" + trang, true);
    xmlhttp.send();
}