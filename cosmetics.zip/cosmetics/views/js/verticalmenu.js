$(document).ready(function(){
  $('ul .sub-menu:not(:first)').hide();
    $('.parent li a').click(function(){
      $('ul .sub-menu').slideUp('slow');
      $(this).parent().next().slideDown('slow');
      return false;
    });
});
