
<form action="models/loaisp.php" method="post" enctype="multipart/form-data">
<table style="width: 1100px;">
		<tr>
			<th width="500"></th>
			<th width="586"></th>
			<th width="558"></th>
		</tr>
		<tr>
			<td>Mã loại sản phẩm</td>
			<td>Tên loại sản phẩm</td>
			<td>Tên danh mục</td>
		</tr>
		<tr>
			<td><input type="Text" name="id_loaisp" id="id_loaisp"></td>
			<td><input type="Text" name="tenloaisp" id="tenloaisp"></td>
			<?php
				include("models/config.php");
				$sql="select * from danhmucsanpham";
				$rs=mysql_query($sql);  
			?>
			<td><select style="width: 200px;" name="tendm">
			<?php
				while ($row=mysql_fetch_array($rs)) {
				  	# code...  
			?>
				<option value="<?php echo $row['ID_DanhMuc'] ?>"><?php echo $row['TenDanhMuc'] ?></option>
			<?php
				}  
			?>
		</tr>
		<tr>
			<td><p></p></td>
		</tr>
		<tr>
			<td><a href="QuanLySanPham.php?quanly=quanlyloaisp&ac=them&id_admin=<?php echo $_GET['id_admin'] ?>"><button name="them" value="Thêm">Thêm</button></a></td>
		</tr>
</table>
<div><p style="font-size: 21px; font-weight: bold; text-align: center; text-indent: 350px;">Danh sách loại sản phẩm</p></div>
</form>
