
<form action="models/sanpham.php?id_admin=<?php echo $_GET['id_admin'] ?>" method="post" enctype="multipart/form-data">
<table style="width: 1100px;">
		<tr>
			<th width="500"></th>
			<th width="586"></th>
			<th width="558"></th>
		</tr>
		<tr>
			<td>Mã sản phẩm</td>
			<td>Loại sản phẩm</td>
			<td>Tên sản phẩm</td>
		</tr>
		<tr>
			<td><input type="Text" name="id_sp" id="id_sp"></td>
			<?php
				include("models/config.php");
				$sql="select * from loaisanpham";
				$rs=mysql_query($sql);  
			?>
			<td><select style="width: 200px;" name="loaisp">
			<?php
				while ($row=mysql_fetch_array($rs)) {
				  	# code...  
			?>
				<option value="<?php echo $row[0] ?>"><?php echo $row[1] ?></option>
			<?php
				}  
			?>
			</select></td>
			<td><input type="Text" name="tensp" id="tensp"></td>
		</tr>
		<tr>
			<td><p></p></td>
			<td><p></p></td>
			<td><p></p></td>
		</tr>
		<tr>
			<td>Thông tin sản phẩm</td>
			<td>Hướng dẫn sử dụng</td>
		</tr>
		<tr>
			<td><textarea type="Text" name="ttsp" id="ttsp" cols="30" rows="10"></textarea></td>
			<td><textarea type="Text" name="hdsd" id="hdsd" cols="30" rows="10"></textarea></td>
		</tr>
		<tr>
			<td><button name="them" value="Thêm">Thêm</button></a></td>
		</tr>
</table>
<div><p style="font-size: 21px; font-weight: bold; text-align: center; text-indent: 450px;">Danh sách sản phẩm</p></div>
</form>
