<?php
	include("models/config.php");
	$sql="select * from khachhang a";
	$rs=mysql_query($sql);
?>
<div><p></p><br>
<table border=1 id="tab">
	<tr  style="border: 1px solid #111;">
		<th style="text-align: center;">Mã thành viên</th>
		<th style="text-align: center;">Họ tên</th>
		<th style="text-align: center;">Địa chỉ</th>
		<th style="text-align: center;">Quận huyện</th>
		<th style="text-align: center;">Tỉnh</th>
		<th style="text-align: center;">Số điện thoại</th>
		<th style="text-align: center;">Email</th>
		<th style="text-align: center;">Mật khẩu</th>
		<th style="text-align: center;" colspan="2">Quản lý</th>
	</tr>
    <?php
    	if($rs === FALSE) { 
   	 		die(mysql_error()); // TODO: better error handling
		}
    	$i=1;
		while($row=mysql_fetch_array($rs)){
	?>
	<tr>
		<td><?php echo $row['ID_KH'] ?></td>
        <td><?php echo $row['HoTen'] ?></td>
        <td><?php echo $row['DiaChi'] ?></td>
        <td><?php echo $row['Quan_Huyen'] ?></td>
        <td><?php echo $row['Tinh'] ?></td>
        <td><?php echo $row['SoDienThoai'] ?></td>
        <td><?php echo $row['Email'] ?></td>
        <td><?php echo $row['MatKhau'] ?></td>
		<td><a href="QuanLyThanhVien.php?quanly=quanlytv&ac=sua&id=<?php echo $row['ID_kh'] ?>&id_admin=<?php echo $_GET['id_admin'] ?>">Sửa</a></td>
		<td><a href="models/thanhvien.php?id=<?php echo $row['ID_kh']; ?>&id_admin=<?php echo $_GET['id_admin'] ?>">Xóa</a></td>
    <?php
    	$i++;
		}
	?>
</table>
</div>