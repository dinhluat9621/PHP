<?php
	include("models/config.php");
	$sql="select * from sanpham sp, loaisanpham l where sp.id_loaisp=l.id_loaisp order by sp.id_sanpham asc";
	$rs=mysql_query($sql);
?>
<div><p></p><br>
<table border=1 id="tab">
	<tr  style="border: 1px solid #111;">
		<th style="text-align: center;">Mã SP</th>
		<th style="text-align: center;">Loại sản phẩm</th>
		<th style="text-align: center;">Tên sản phẩm</th>
		<th style="text-align: center;">Thông tin sản phẩm</th>
		<th style="text-align: center;">Hướng dẫn sử dụng</th>
		<th style="text-align: center;">Ngày thêm</th>
		<th style="text-align: center;" colspan="3">Quản lý</th>
	</tr>
    <?php
    	if($rs === FALSE) { 
   	 		die(mysql_error()); // TODO: better error handling
		}
    	$i=1;
		while($row=mysql_fetch_array($rs)){
	?>
	<tr>
		<td><?php echo $row['ID_SanPham'] ?></td>
        <td><?php echo $row['TenLoaiSP'] ?></td>
        <td><?php echo $row['TenSanPham'] ?></td>
        <td><?php echo $row['ThongTinSP'] ?></td>
        <td><?php echo $row['HuongDanSD'] ?></td>
        <td><?php echo $row['NgayThem'] ?></td>
		<td><a href="QuanLySanPham.php?quanly=quanlysp&ac=sua&id=<?php echo $row['ID_SanPham'] ?>&id_admin=<?php echo $_GET['id_admin'] ?>">Sửa</a></td>
		<td><a href="models/sanpham.php?id=<?php echo $row['ID_SanPham']; ?>&id_admin=<?php echo $_GET['id_admin'] ?>">Xóa</a></td>
		<td><a href="QuanLySanPham.php?quanly=quanlyctsp&ac=them&id=<?php echo $row['ID_SanPham'] ?>&id_admin=<?php echo $_GET['id_admin'] ?>">Chi tiết</a></td>
	</tr>
    <?php
    	$i++;
		}
	?>
</table>
</div>