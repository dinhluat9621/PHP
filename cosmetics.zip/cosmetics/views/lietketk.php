<?php
	include("models/config.php");
	$sql="select * from admin a";
	$rs=mysql_query($sql);
?>
<div><p></p><br>
<table border=1 id="tab">
	<tr  style="border: 1px solid #111;">
		<th style="text-align: center;">Mã tài khoản</th>
		<th style="text-align: center;">Tên đăng nhập</th>
		<th style="text-align: center;">Mật khẩu</th>
		<th style="text-align: center;" colspan="2">Quản lý</th>
	</tr>
    <?php
    	if($rs === FALSE) { 
   	 		die(mysql_error()); // TODO: better error handling
		}
    	$i=1;
		while($row=mysql_fetch_array($rs)){
	?>
	<tr>
		<td><?php echo $row['ID'] ?></td>
        <td><?php echo $row['Username'] ?></td>
        <td><?php echo $row['Password'] ?></td>
		<td><a href="QuanLy.php?quanly=quanlytk&ac=sua&id=<?php echo $row['ID'] ?>&id_admin=<?php echo $_GET['id_admin'] ?>">Sửa</a></td>
		<td><a href="models/taikhoan.php?id=<?php echo $row['ID']; ?>&id_admin=<?php echo $_GET['id_admin'] ?>">Xóa</a></td>
    <?php
    	$i++;
		}
	?>
</table>
</div>