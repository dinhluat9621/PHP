<?php
	ob_start();
	session_start(); 
?>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Phấn mắt | Gumiho</title>
	<link rel="stylesheet" href="css/cosmetic.css">
	<link rel="stylesheet" href="css/dangnhap.css">
	<link rel="stylesheet" href="css/banchay.css">
	<link rel="stylesheet" href="css/mat.css">
	<link rel="stylesheet" href="css/totalprice.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<script type="text/javascript" src="js/jquery-3.2.0.min.js"></script>
	<script type="text/javascript" src="js/verticalmenu.js"></script>
</head>
<body>
	<?php
		if(!isset($_GET['id_kh'])){
			header('location:DangNhap.php');
		}  
	?>
	<div id="navigation">
		<ul>
			<li><a href="#">BLOG LÀM ĐẸP</a></li>
			<li><a href="#">THÔNG TIN SƯ KIÊN</a></li>
			<li><a href="LienHe.php">LIÊN HỆ</a></li>
			<li><a href="#">TUYỂN DỤNG</a></li>
			<li><a href="">GIỎ HÀNG</a></li>
			<li class="sign" style="border-style:none;">
	        <form action="models/timkiem.php" method="post" accept-charset="utf-8" enctype="multipart/form-data">
	          <input type="submit" id="searchbtn" name="search" value="Search" style="border-style: solid; color: white; background: #111;); height: 30px; width: 50px;">
	        </form>
	      </li>
			<li class="sign"><input type="search" placeholder="Tìm kiếm..."></li>
			<?php
		        if(isset($_GET['id_kh'])) {
	      	?>
			<li class="sign"><a href="../index.php">Đăng xuất</a></li>
	      	<?php
		        }
		        else{  
	      	?>
			<li class="sign"><a href="DangNhap.php">Đăng nhập</a></li>
	      	<?php
		        }  
      		?>
		</ul>
	</div>
	<!-- Left -->
		<div class="col-md-2" id="left"></div>
	<!-- Content -->
		<div class="col-md-8" id="content">
      		<!-- Logo content -->
	        <div class="logo_content">
	          <a href="../index.php"><img src="image/gumiho.png" id="logo"></a>
	          <div class="right_logo">
	            <div>
	              <p>
	                <span style="font-family:arial,helvetica,sans-serif">
	                  <span style="font-size:16px">
	                    <strong>MIỄN PHÍ GIAO HÀNG VỚI HÓA ĐƠN TỪ&nbsp;400.000 VNĐ TẠI&nbsp;TP HỒ CHÍ MINH</strong>
	                  </span>
	                </span>
	              </p>
	              <p>
	                  <span style="font-family:arial,helvetica,sans-serif">
	                    <span style="font-size:16px">
	                      <strong>MIỄN PHÍ GIAO HÀNG VỚI HÓA ĐƠN TỪ 600.000 VNĐ ĐỐI VỚI CÁC KHU VỰC KHÁC</strong>
	                    </span>
	                  </span>
	              </p>
	            </div>
	          </div>
	        </div>
      		<!-- Logo content -->
			<div id="menu"><br>
			  	<ul>
			  		<li><a href="#">MỚI</a></li>
			  		<li><a href="BanChay.php">BÁN CHẠY</a></li>
				    <li><a href="#">MẮT</a>
		      	<ul class="submenu">
		        <?php
                  if(isset($_GET['id_kh'])) {
                ?>
			        <li><a href="PhanMat.php?xem=phanmat&id_kh=<?php echo $_GET['id_kh'] ?>">Phấn mắt</a></li>
			        <li><a href="KeMat.php">Kẻ mắt</a></li>
			        <li><a href="Mascara.php">Mascara</a></li>
	                <li><a href="CoMat.php">Cọ mắt</a></li>
                <?php
                  }
                  else{ 
                ?>
	                <li><a href="PhanMat.php">Phấn mắt</a></li>
	                <li><a href="KeMat.php">Kẻ mắt</a></li>
	                <li><a href="Mascara.php">Mascara</a></li>
	                <li><a href="CoMat.php">Cọ mắt</a></li>
                <?php
                  }  
                ?>
			      </ul>
				    </li>
					<li><a href="#">MÔI</a>
			            <ul class="submenu">
			              <li><a href="#">Son bóng</a></li>
			              <li><a href="#">Son môi</a></li>
			              <li><a href="#">Kẻ môi</a></li>
			              <li><a href="#">Dưỡng môi</a></li>
			              <li><a href="#">Cọ môi</a></li>  
			            </ul>
          			</li>
					<li><a href="#">MẶT</a>
			            <ul class="submenu">
			              <li><a href="#">Dưỡng da</a></li>
			              <li><a href="#">Kem nền</a></li>
			              <li><a href="#">Che khuyết điểm</a></li>
			              <li><a href="#">Phấn</a></li>
			              <li><a href="#">Má hồng</a></li>
			              <li><a href="#">Pallette cho mặt</a></li>
			              <li><a href="#">Tạo khối</a></li>
			              <li><a href="#">Cọ</a></li>
			              <li><a href="#">Tẩy trang</a></li>
			              <li><a href="#">Kem lót</a></li>
			              <li><a href="#">Kem dưỡng trang điểm</a></li>
			              <li><a href="#">Trang điểm ánh nhũ</a></li>
			              <li><a href="#">Dụng cụ</a></li>  
			            </ul>
          			</li>
					<li><a href="#">MÓNG</a>
			            <ul class="submenu">
			              <li><a href="#">Sơn móng tay</a></li>
			              <li><a href="#">Sản phẩm cho móng</a></li>
			              <li><a href="#">Dụng cụ làm móng</a></li>
			            </ul>
          			</li>
					<li><a href="#">DỤNG CỤ</a>
			            <ul class="submenu">
			              <li><a href="#">Bộ cọ</a></li>
			              <li><a href="#">Cọ lẻ</a></li>
			              <li><a href="#">Bông phấn</a></li>
			              <li><a href="#">Phấn</a></li>
			              <li><a href="#">Phụ kiện trang điểm</a></li>
			              <li><a href="#">Hộp đựng</a></li>
			              <li><a href="#">Bấm mi</a></li>
			              <li><a href="#">Gương</a></li>
			              <li><a href="#">Đồ chuốt</a></li>
			              <li><a href="#">Nhíp</a></li>
			              <li><a href="#">Vẽ chân mày</a></li>  
			            </ul>
          			</li>
			  	</ul>
			</div>
			<div><p></p></div>
			<div class="sub-menu">
			  	<ul class="">
			  		<li>
			  			<a href="TrangChu.php">Trang chủ</a>
		  			</li>
					<li><a href="">Giỏ hàng</a></li>
			  	</ul>
			</div>
			<div class="table-responsive cart_info">
				<table class="table table-condensed">
					<thead>
						<tr class="cart_menu" style="background: #111; color: white;">
							<td class="image">Sản phẩm</td>
							<td class="description"></td>
							<td class="price">Giá</td>
							<td class="quantity">Số lượng</td>
							<td class="total">Thành tiền</td>
							<td></td>
						</tr>
					</thead>
					<tbody>
					<?php
					include("../models/config.php");
					if(isset($_GET['add'] ) && !empty($_GET['add'])){
						$id=$_GET['add'];
						@$_SESSION['giohang_'.$id]+=1;
						header('location:giohang.php?xem=giohang&id_kh='.$_GET['id_kh']);
					}   
					if(isset($_GET['them'])){
						$_SESSION['giohang_'.$_GET['them']]+=1;
						header('location:giohang.php?xem=giohang&id_kh='.$_GET['id_kh']);					
					}
					if(isset($_GET['bo'])){
						$_SESSION['giohang_'.$_GET['bo']]-=1;
						header('location:giohang.php?xem=gio-hang&id_kh='.$_GET['id_kh']);
					}
					if(isset($_GET['xoa'])){
						$_SESSION['giohang_'.$_GET['xoa']]=0;
						header('location:giohang.php?xem=gio-hang&id_kh='.$_GET['id_kh']);
					}
					if(isset($_SESSION['value'])){
						$value=$_SESSION['value'];
					}

					$tongtien=0;
					foreach ($_SESSION as $name => $value) {
						if($value>0){
							if(substr($name,0,8)=='giohang_'){
								$id=substr($name,8,strlen($name-8));
								$sql="select * from chitietsanpham where id_sanpham='".$id."'";
								$rs=mysql_query($sql); 
								$sql_sp="select * from sanpham where id_sanpham='".$id."'";
								$rs_sp=mysql_query($sql_sp);
								while ($row=mysql_fetch_array($rs)) {
									while($row_sp=mysql_fetch_array($rs_sp)){
							  			$thanhtien=$row['Gia']*$value;
					?>
						<tr>
							<td class="cart_product">
								<a href=""><img style="width: 100px; height: 100px;" src="image/<?php echo $row['Anh'] ?>" alt=""></a>
							</td>
							<td class="cart_description">
								<h4><a style="text-decoration: none; color: #111;" href=""><?php echo $row_sp['TenSanPham'] ?></a></h4>
							</td>
							<?php
								}  
							?>
							<td class="cart_price">
								<p><?php echo $row['Gia']?> VND</p>
							</td>
							<td class="cart_quantity">
								<div class="cart_quantity_button">
									<a href="giohang.php?xem=gio-hang&them=<?php echo $row['ID_SanPham'] ?>&id_kh=<?php echo $_GET['id_kh'] ?>" style="text-decoration: none; font-size: 18px; color: #ff1a75;">+ </a>
									<input class="cart_quantity_input" type="text" name="quantity" value="<?php echo $value ?>" autocomplete="off" size="2">
									<a href="giohang.php?xem=gio-hang&bo=<?php echo $row['ID_SanPham'] ?>&id_kh=<?php echo $_GET['id_kh'] ?>" style="text-decoration: none; font-size: 18px; color: #ff1a75;"> -</a>
								</div>
							</td>
							<td class="cart_total">
								<p class="cart_total_price"><?php echo $thanhtien ?> VND</p>
							</td>
							<td class="cart_delete">
								<a class="cart_quantity_delete" style="text-decoration: none;" href="giohang.php?xem=gio-hang&xoa=<?php echo $row['ID_SanPham'] ?>">Xóa<i class="fa fa-times"></i></a>
							</td>
						</tr>
						<?php
								}
								$tongtien+=$thanhtien;
								$_SESSION['tongtien']=$tongtien;

							}
							
						}
					}
						?>
					
					</tbody>
				</table>
			</div>
			<div class="col-sm-6" style="float: right;">
				<div class="total_area">
					<ul>
						<li>Tổng cộng: <span><?php echo $tongtien ?> </span></li>
					</ul>
						<a style="float: right; background: #ff1a75; color: white; font-weight: bold;" class="btn btn-default check_out" href="checkout.php?xem=thanhtoan&id_kh=<?php echo $_GET['id_kh'] ?>">Thanh toán</a>
				</div>
			</div>
			<section>
				<div>
					<p></p><br>
				</div>
			</section>
			<section class="about-sect">
				<div>
				  	<table id="table_3">
					    <tr>	
					      <th><p></p>Tại sao lại chọn chúng tôi?</th>
					    </tr>
					    <tr>
					    	<td>
					    		<p></p>
					    	</td>
					    </tr>
					    <tr>
					    	<td>gumiho cosmetics là nhãn hiệu mỹ phẩm không thể thiếu cho nhu cầu trang 
              					điểm và làm đẹp mỗi ngày của bạn. Tại gumiho, chúng tôi cung cấp những 
              					sản phẩm chất lượng với giá cả phải chăng đem lại nét rạng rỡ tự nhiên 
	              				cho gương mặt với sự đa dạng về chủng loại sản phẩm, son bóng quyến rũ 
	              				nhiều tông màu với nhiều kiểu dáng khác nhau cũng như son môi dưỡng 
	              				ẩm chuyên sâu đem lại màu sắc tươi tắn và lâu phai suốt cả ngày.
					    	</td>
					    </tr>
			            <tr>
			              <td><p></p></td>
			            </tr>
			            <tr>
			              <td>Bên cạnh đó, dòng sản phẩm trang điểm khoáng chất của gumiho an toàn không chứa màu 
	          				nhuộm hóa học và chất bảo quản giúp nuôi dưỡng làn da của bạn sáng bóng, khỏe mạnh hơn.
			              </td>
			            </tr>
					    <tr>
					    	<td>
					    		<p></p>
					    	</td>
					    </tr>
				    </table>
				</div>
	      		<p id="p">a</p>
				<div>
					<p class="font1"><br>Copyright &copy 2017 Gumiho Cosmetics VN. Powered by UIT</p>
				</div>
			</section>
			<div>
		        <table id="table_5">
		          <th><img src="image/peta.png" id="image"></th>
		          <th><img src="image/logo_client.png" id="image"></th>
		          <th><img src="image/paypal.png" id="image"></th>
		        </table>
			</div>
		</div>
	<!-- Right -->
		<div class="col-md-2" id="right"></div>
	<!-- Footer -->
  		<div class="col-md-12" id="footer" >
  			<table id="table_4">	
  					<tr>
  						<p></p>
  					</tr>
  					<tr>
  						<th id="column">SẢN PHẨM MỚI</th>
  						<th id="column">MẮT<p></p></th>
  						<th id="column">MÔI</th>
  						<th id="column">MẶT</th>
  						<th id="column">MÓNG</th>
  					</tr>
  					<tr>
  						<td>BÁN CHẠY</td>
  						<td>Phấn mắt</td>
  						<td>Son bóng</td>
  						<td>Dưỡng da</td>
  						<td>Sơn móng tay</td>
  					</tr>
  					<tr>
  						<td>BLOG LÀM ĐẸP</td>
  						<td>Kẻ mắt</td>
  						<td>Son môi</td>
  						<td>Kem nền</td>
  						<td>Sản phẩm cho móng</td>
  					</tr>
  					<tr>
  						<td></td>
  						<td>Mascara</td>
  						<td>Cọ môi</td>
  						<td>Che khuyết điểm</td>
  						<td>Dụng cụ làm móng</td>

  					</tr>
  					<tr>
  						<td></td>
  						<td>Cọ mắt</td>
  						<td></td>
  						<td>Phấn & Má hồng</td>
  						<td></td>
  					</tr>
  					<tr>
  						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  					</tr>
  					<tr>
  						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  					</tr>
  					<tr>
  						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  					</tr>
  					<tr>
  						<td></td>
  						<td></td>
  						<td></td> 
  						<td></td>
  					</tr>
  					<tr>
  						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  					</tr>
  					<tr>
  						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  					</tr>
  					<tr>
  						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  					</tr>
  					<tr>
  						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  					</tr>
  					<tr>
						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  					</tr>
  			</table>
  		</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script> 
<script src="js/bootstrap.min.js"></script>
</body>
</html>
<?php
	ob_flush();  
?>