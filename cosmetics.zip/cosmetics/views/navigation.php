<div id="navigation">
		<ul>
			<li><a href="#">BLOG LÀM ĐẸP</a></li>
			<li><a href="#">THÔNG TIN SƯ KIÊN</a></li>
			<li><a href="LienHe.php">LIÊN HỆ</a></li>
			<li><a href="#">TUYỂN DỤNG</a></li>
			<li><a href="#">GIỎ HÀNG</a></li>
      <li class="sign" style="border-style:none;">
        <form action="models/timkiem.php" method="post" accept-charset="utf-8" enctype="multipart/form-data">
          <input type="submit" id="searchbtn" name="search" value="Search" style="border-style: solid; color: white; background: #111;); height: 30px; width: 50px;">
        </form>
      </li>
			<li class="sign" >
        <form action="" method="post">
          <input type="search" id="searchf" name="searchtext" placeholder="Tìm kiếm...">
        </form>
      </li>
      
			<li class="sign"><a href="views/DangNhap.php">Đăng nhập</a></li>
		</ul>
</div>