
<form action="models/ctsp.php?id=<?php echo $_GET['id'] ?>&id_admin=<?php echo $_GET['id_admin'] ?>" method="post" enctype="multipart/form-data">
<table style="width: 1100px;">
		<tr>
			<th width="347"></th>
			<th width="586"></th>
			<th width="558"></th>
            <th width="163"></th>
		</tr>
		<tr>
			<td>Mã sản phẩm</td>
			<td>Màu sản phẩm</td>
			<td>Số lượng</td>
		</tr>
		<tr>
			<td><input readonly="true" type="Text" name="id_sp" id="id_sp" value="<?php echo $_GET['id'] ?>"></td>
			<td><input type="Text" name="mausp" id="mausp"></td>
			<td><input type="Text" name="sl" id="sl"></td>
			
		</tr>
		<tr>
			<td><p></p></td>
			<td><p></p></td>
			<td><p></p></td>
		</tr>
		<tr>
			<td>Gía</td>
			<td>Ảnh</td>
			<td>Gía KM</td>
            
		</tr>
		<tr>
			<td><input type="Text" name="gia" id="gia"></td>
			<td><input type="File" name="anh" id="anh"></td>
            <td><input type="Text" name="giakm" id="giakm"></td>
            
		</tr>
		<tr>
			<td><p></p></td>
			<td><p></p></td>
			<td><p></p></td>
		</tr>
		<tr>
			<td>Tình trạng</td>
            <td>Số lượng đã bán</td>
		</tr>
		<tr>
			<td><input type="Text" name="tinhtrang" id="tinhtrang"></td>
			<td><input type="Text" name="sldb" id="sldb"></td>
		</tr>
		<tr>
			<td><input type="submit" name="them" id="them" value="Thêm"></td>
		</tr>
</table>
<div><p style="font-size: 21px; font-weight: bold; text-align: center; text-indent: 300px;">Chi tiết sản phẩm</p></div>
</form>
