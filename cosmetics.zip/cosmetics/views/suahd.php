<?php
	$sql="select * from hoadon where id=$_GET[id]";
	$rs=mysqli_query($conn,$sql);
	$dong=mysqli_fetch_array($rs);
	/*models/taikhoan.php?id=<?php echo $dong['ID_SanPham'] ?>*/
?>
<form action="models/hoadon.php?id=<?php echo $dong['ID'] ?>" method="post" enctype="multipart/form-data"> 
<table width="1674" id="tab_2">
		<tr>
			<th width="347"></th>
			<th width="586"></th>
			<th width="558"></th>
            <th width="163"></th>
		</tr>
		<tr>
			<td>Mã hóa đơn</td>
			<td>Tên khách hàng</td>
			<td>Thành tiền</td>
		</tr>
		<tr>
			<td><input type="Text" name="id_hd" id="id_hd" cols="30" rows="1" value=""><?php echo $dong['ID_HD'] ?></td>
			<?php
				$sql_lsp="select * from khachhang";
				$rs_lsp=mysqli_query($conn,$sql_lsp);  
			?>
			<td><select name="khachhang">
			<?php
				while ($dong_lsp=mysqli_fetch_array($rs_lsp)) {
				  	if($dong['ID_KH']==$dong_lsp['ID_KH']){ 
			?>
						<option selected="selected" value="<?php echo $dong_lsp['ID_KH'] ?>"><?php echo $dong_lsp['ID_KH'] ?></option>
			<?php
					}
					else{  
			?>
						<option value="<?php echo $dong_lsp['ID_KH'] ?>"><?php echo $dong_lsp['ID_KH'] ?></option>
			<?php
						}
				}  
			?></select></td>
			<td><input type="Text" name="thanhtien" id="thanhtien" cols="30" rows="1" value=""><?php echo $dong['thanhtien'] ?></td>
		</tr>
		<tr>
			<td><p></p></td>
			<td><p></p></td>
			<td><p></p></td>
		</tr>
		<tr>
			<td><input type="submit" name="sua" id="sua" value="Sửa"></td>
		</tr>
</table>
<div><p style="font-size: 21px; font-weight: bold; text-align: center; text-indent: 450px;">Danh sách hóa đơn</p></div>
</form>
<div><p></p></div>