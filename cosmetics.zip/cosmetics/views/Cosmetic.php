<head>
	<title>Cometics</title>
	<meta charshet="utf-8"/>
	<link rel="stylesheet"  href="cosmetic.css" type="text/css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/bootstrap-theme.min.css">
</head>
<body>
<nav>
	<ul class="naviga">
		<li><a class="naviga" href="">BLOG LÀM ĐẸP</a></li>
		<li><a class="naviga" href="">HỆ THỐNG CỬA HÀNG</a></li>
		<li><a class="naviga" href="LienHe.html">LIÊN HỆ</a></li>
		<li><a class="naviga" href="">TUYỂN DỤNG</a></li>
		<li><a class="naviga" href="">GIỎ HÀNG</a></li>
		<li class="signin"><a class="naviga" href="DangNhap.html">Đăng nhập</a></li>
  		<li class="signup"><a class="naviga" href="#dangky">Đăng ký</a></li>
	</ul>
</nav>
<div id="top_header">
	<img src="icon.png" id="image">
	<h1>COSMETIC</h1>
</div>
	<ul>
	  <li><a href="#home">Home</a></li>
	  <li><a href="#news">News</a></li>
	  <li class="dropdown">
	    <a href="javascript:void(0)" class="dropbtn">Dropdown</a>
	    <div class="dropdown-content">
	      <a href="#">Link 1</a>
	      <a href="#">Link 2</a>
	      <a href="#">Link 3</a>
	    </div>
	  </li>
	</ul>
</body>
</html>