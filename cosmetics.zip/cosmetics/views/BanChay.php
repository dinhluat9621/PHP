<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Sản phẩm bán chạy | Gumiho</title>
	<link rel="stylesheet" href="css/cosmetic.css">
	<link rel="stylesheet" href="css/dangnhap.css">
	<link rel="stylesheet" href="css/banchay.css">
	<link rel="stylesheet" href="css/mat.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<script type="text/javascript" src="js/jquery-3.2.0.min.js"></script>
	<script type="text/javascript" src="js/verticalmenu.js"></script>
</head>
<body>
	<div id="navigation">
		<ul>
			<li><a href="#">BLOG LÀM ĐẸP</a></li>
			<li><a href="LienHe.php">LIÊN HỆ</a></li>
			<li><a href="#">GIỎ HÀNG</a></li>
			<li class="sign" style="border-style:none;">
	        <form action="models/timkiem.php" method="post" accept-charset="utf-8" enctype="multipart/form-data">
	          <input type="submit" id="searchbtn" name="search" value="Search" style="border-style: solid; color: white; background: #111;); height: 30px; width: 50px;">
	        </form>
	      </li>
			<li class="sign"><input type="search" placeholder="Tìm kiếm..."></li>
			<?php
				if(isset($_GET['id_kh']) || isset($_GET['id_admin'])){
			?>
			<li class="sign"><a href="../index.php">Đăng xuất</a></li>
			<?php
				}
				else{  
			?>
			<li class="sign"><a href="DangNhap.php">Đăng nhập</a></li>
			<?php
				}  
			?>
		</ul>
	</div>

	<!-- Left -->
		<div class="col-md-2" id="left"></div>

	<!-- Content -->
		<div class="col-md-8" id="content">
      		<!-- Logo content -->
	        <div class="logo_content">
	        <?php
	        	if(isset($_GET['id_kh'])){  
	        ?>
	          <a href="../index.php?xemtrangchu&id_kh=<?php echo $_GET['id_kh'] ?>"><img src="image/gumiho.png" id="logo"></a>
          	<?php
          		}if(isset($_GET['id_admin'])){  
          	?>
          	<a href="admin.php?xem=trangchu&id_admin=<?php echo $_GET['id_admin']?>"><img src="image/gumiho.png" id="logo"></a>
          	<?php
          		}else{  
          	?>
          	<a href="../index.php"><img src="image/gumiho.png" id="logo"></a>
          	<?php
          		}  
          	?>
	          <div class="right_logo">
	            <div>
	              <p>
	                <span style="font-family:arial,helvetica,sans-serif">
	                  <span style="font-size:16px">
	                    <strong>MIỄN PHÍ GIAO HÀNG VỚI HÓA ĐƠN TỪ&nbsp;400.000 VNĐ TẠI&nbsp;TP HỒ CHÍ MINH</strong>
	                  </span>
	                </span>
	              </p>

	              <p>
	                  <span style="font-family:arial,helvetica,sans-serif">
	                    <span style="font-size:16px">
	                      <strong>MIỄN PHÍ GIAO HÀNG VỚI HÓA ĐƠN TỪ 600.000 VNĐ ĐỐI VỚI CÁC KHU VỰC KHÁC</strong>
	                    </span>
	                  </span>
	              </p>
	            </div>
	          </div>
	        </div>
      		<!-- Logo content -->
			<div id="menu">
        <br>
			  	<ul>
			  	<li><a href="SanPhamMoi.php">MỚI</a></li>
            <li><a href="BanChay.php">BÁN CHẠY</a></li>
				    <li><a href="#">MẮT</a>
				      <ul class="submenu">
				        <li><a href="views/PhanMat.php">Phấn mắt</a></li>
				        <li><a href="views/KeMat.php">Kẻ mắt</a></li>
				        <li><a href="views/Mascara.php">Mascara</a></li>
                <li><a href="views/CoMat.php">Cọ mắt</a></li>
				      </ul>
				    </li>
					<li><a href="#">MÔI</a>
            <ul class="submenu">
              <li><a href="#">Son bóng</a></li>
              <li><a href="SonMoi.php">Son môi</a></li>
              <li><a href="#">Cọ môi</a></li>  
            </ul>
          </li>
					<li><a href="#">MẶT</a>
            <ul class="submenu">
              <li><a href="#">Dưỡng da</a></li>
              <li><a href="#">Kem nền</a></li>
              <li><a href="#">Che khuyết điểm</a></li>
              <li><a href="#">Phấn & Má hồng</a></li>
            </ul>
          </li>
					<li><a href="#">MÓNG</a>
            <ul class="submenu">
              <li><a href="#">Sơn móng</a></li>
              <li><a href="#">Dụng cụ</a></li>
            </ul>
          </li>
					
			  	</ul>
			</div>
			<div float="right">
				<img src="image/best_seller.png">
			</div>
			<div><p></p></div>
			<div class="sub-menu">
			  	<ul class="">
			  		<li>
			  			<a href="../index.php">TRANG CHỦ</a>
		  			</li>
					<li>
						<a>SẢN PHẨM BÁN CHẠY</a>
					</li>
			  	</ul>
			</div>

		<section class="col-md-10">
			
			<?php  
					include("../models/config.php");
					$sql="select * from sanpham, chitietsanpham ct where sanpham.id_sanpham=ct.id_sanpham and ct.soluongdaban>10";
					$rs=mysql_query($sql);
				?>
				<div>
					<ul style="width: 885px; list-style-type: none;">
					<?php
						while ($row=mysql_fetch_array($rs)) {
						  	# code...
						  	/*PhanMat.php?view=chitietsanpham&id=<?php echo $row['ID_SanPham']?>*/
					?>
						<li style="width: 275px; height: auto; text-align: center; font-weight: bold; float: left; margin-left: 7px;">
						<a style="text-decoration: none;" 
						href="phanmat_1.php">
							<img src="image/<?php echo $row['Anh'] ?>" style="width: 200px; height: 200px;">
							<p style="color:  #404040;"><?php echo $row['TenSanPham'] ?></p>
							<p style="color:  #404040;">Giá: <?php echo number_format($row['Gia'] , 0)?> VNĐ</p>
						</a>
						</li>
					<?php
						}
					?>
					</ul>
				</div>
		</section>
			<section>
				<div>
					<p></p><br>
				</div>
			</section>
			<section class="about-sect">
				<div>
				  	<table id="table_3">
					    <tr>	
					      <th><p></p>Tại sao lại chọn chúng tôi?</th>
					    </tr>
					    <tr>
					    	<td>
					    		<p></p>
					    	</td>
					    </tr>
					    <tr>
					    	<td>gumiho cosmetics là nhãn hiệu mỹ phẩm không thể thiếu cho nhu cầu trang 
              					điểm và làm đẹp mỗi ngày của bạn. Tại gumiho, chúng tôi cung cấp những 
              					sản phẩm chất lượng với giá cả phải chăng đem lại nét rạng rỡ tự nhiên 
	              				cho gương mặt với sự đa dạng về chủng loại sản phẩm, son bóng quyến rũ 
	              				nhiều tông màu với nhiều kiểu dáng khác nhau cũng như son môi dưỡng 
	              				ẩm chuyên sâu đem lại màu sắc tươi tắn và lâu phai suốt cả ngày.
					    	</td>
					    </tr>
			            <tr>
			              <td><p></p></td>
			            </tr>
			            <tr>
			              <td>Bên cạnh đó, dòng sản phẩm trang điểm khoáng chất của gumiho an toàn không chứa màu 
	          				nhuộm hóa học và chất bảo quản giúp nuôi dưỡng làn da của bạn sáng bóng, khỏe mạnh hơn.
			              </td>
			            </tr>
					    <tr>
					    	<td>
					    		<p></p>
					    	</td>
					    </tr>
				    </table>
				</div>
				
	      		<p id="p">a</p>
				<div>
					<p class="font1"><br>Copyright &copy 2017 Gumiho Cosmetics VN. Powered by UIT</p>
				</div>
			</section>
			<div>
		        <table id="table_5">
		          <th><img src="image/peta.png" id="image"></th>
		          <th><img src="image/logo_client.png" id="image"></th>
		          <th><img src="image/paypal.png" id="image"></th>
		        </table>
			</div>
		</div>

	<!-- Right -->
		<div class="col-md-2" id="right"></div>

	<<!-- Footer -->
  		<div class="col-md-12" id="footer" style="height: 160px; background-color: gray;" >
  			<table id="table_4">	
  					<tr>
  						<p></p>
  					</tr>
  					<tr>
  						<th id="column">SẢN PHẨM MỚI</th>
  						<th id="column">MẮT<p></p></th>
  						<th id="column">MÔI</th>
  						<th id="column">MẶT</th>
  						<th id="column">MÓNG</th>
  					</tr>
  					<tr>
  						<td>BÁN CHẠY</td>
  						<td>Phấn mắt</td>
  						<td>Son bóng</td>
  						<td>Dưỡng da</td>
  						<td>Sơn móng tay</td>
  					</tr>
  					<tr>
  						<td>BLOG LÀM ĐẸP</td>
  						<td>Kẻ mắt</td>
  						<td>Son môi</td>
  						<td>Kem nền</td>
  						<td>Sản phẩm cho móng</td>
  					</tr>
  					<tr>
  						<td></td>
  						<td>Mascara</td>
  						<td>Cọ môi</td>
  						<td>Che khuyết điểm</td>
  						<td>Dụng cụ</td>

  					</tr>
  					<tr>
  						<td></td>
  						<td>Cọ mắt</td>
  						<td></td>
  						<td>Phấn & Má hồng</td>
  						<td></td>
  					</tr>
  					<tr>
  						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  					</tr>
  					<tr>
  						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  					</tr>
  					<tr>
  						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  					</tr>
  					<tr>
  						<td></td>
  						<td></td>
  						<td></td> 
  						<td></td>
  					</tr>
  					<tr>
  						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  					</tr>
  					<tr>
  						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  					</tr>
  					<tr>
  						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  					</tr>
  					<tr>
  						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  					</tr>
  					<tr>
						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  					</tr>
  			</table>
  		</div>
    <!-- Footer -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script> 
<script src="js/bootstrap.min.js"></script>
</body>
</html>