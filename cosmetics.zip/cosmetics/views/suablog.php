<?php
	$sql="select * from blog where id=$_GET[id]";
	$rs=mysqli_query($conn,$sql);
	$dong=mysqli_fetch_array($rs);
	/*models/taikhoan.php?id=<?php echo $dong['ID_SanPham'] ?>*/
?>
<form action="models/blog.php?id=<?php echo $dong['ID'] ?>" method="post" enctype="multipart/form-data"> 
<table width="1674" id="tab_2">
		<tr>
			<th width="347"></th>
			<th width="586"></th>
			<th width="558"></th>
            <th width="163"></th>
		</tr>
		<tr>
			<td>Mã blog</td>
			<td>Ảnh</td>
			<td>Nội dung</td>
		</tr>
		<tr>
			<td><input type="Text" name="id_blog" id="id_blog" cols="30" rows="1" value=""><?php echo $dong['ID_blog'] ?></td>
			<td><input type="Text" name="anh" id="anh" cols="30" rows="1" value=""><?php echo $dong['anh'] ?></td>
			<td><input type="Text" name="noidung" id="noidung" cols="30" rows="1" value=""><?php echo $dong['noidung'] ?></td>
		</tr>
		<tr>
			<td><p></p></td>
			<td><p></p></td>
			<td><p></p></td>
		</tr>
		<tr>
			<td><input type="submit" name="sua" id="sua" value="Sửa"></td>
		</tr>
</table>
<div><p style="font-size: 21px; font-weight: bold; text-align: center; text-indent: 450px;">Danh sách Blog</p></div>
</form>
<div><p></p></div>