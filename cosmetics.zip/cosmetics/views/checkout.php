<?php
	ob_start();
	session_start();  
?>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Phấn mắt | Gumiho</title>
	<link rel="stylesheet" href="css/cosmetic.css">
	<link rel="stylesheet" href="css/dangnhap.css">
	<link rel="stylesheet" href="css/banchay.css">
	<link rel="stylesheet" href="css/mat.css">
	<link rel="stylesheet" href="css/totalprice.css">
	<link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/price-range.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
	<link href="css/totalprice.css" rel="stylesheet">
	<link href="css/responsive.css" rel="stylesheet">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
</head>
<body>
	<?php
	    if(!isset($_GET['id_kh'])){
	      header('location:DangNhap.php');
	    }  
  	?>
	<div id="navigation">
		<ul>
			<li><a href="#">BLOG LÀM ĐẸP</a></li>
			<li><a href="#">THÔNG TIN SƯ KIÊN</a></li>
			<li><a href="LienHe.php">LIÊN HỆ</a></li>
			<li><a href="#">TUYỂN DỤNG</a></li>
			<li><a href="giohang.php?id_kh=<?php echo $_GET['id_kh'] ?>">GIỎ HÀNG</a></li>
			<li class="sign" style="border-style:none;">
	        <form action="models/timkiem.php" method="post" accept-charset="utf-8" enctype="multipart/form-data">
	          <input type="submit" id="searchbtn" name="search" value="Search" style="border-style: solid; color: white; background: #111;); height: 30px; width: 50px;">
	        </form>
	      </li>
			<li class="sign"><input type="search" placeholder="Tìm kiếm..."></li>
			<li class="sign"><a href="DangNhap.php">Đăng nhập</a></li>
		</ul>
	</div>

	<!-- Left -->
		<div class="col-md-2" id="left"></div>

	<!-- Content -->
		<div class="col-md-8" id="content">
      		<!-- Logo content -->
	        <div class="logo_content">
	          <a href="../index.php"><img src="image/gumiho.png" id="logo"></a>
	          <div class="right_logo">
	            <div>
	              <p>
	                <span style="font-family:arial,helvetica,sans-serif">
	                  <span style="font-size:16px">
	                    <strong>MIỄN PHÍ GIAO HÀNG VỚI HÓA ĐƠN TỪ&nbsp;400.000 VNĐ TẠI&nbsp;TP HỒ CHÍ MINH</strong>
	                  </span>
	                </span>
	              </p>

	              <p>
	                  <span style="font-family:arial,helvetica,sans-serif">
	                    <span style="font-size:16px">
	                      <strong>MIỄN PHÍ GIAO HÀNG VỚI HÓA ĐƠN TỪ 600.000 VNĐ ĐỐI VỚI CÁC KHU VỰC KHÁC</strong>
	                    </span>
	                  </span>
	              </p>
	            </div>
	          </div>
	        </div>
      		<!-- Logo content -->
			<div id="menu"><br>
			  	<ul>
			  		<li><a href="#">MỚI</a></li>
			  		<li><a href="BanChay.php">BÁN CHẠY</a></li>
				    <li><a href="#">MẮT</a>
				      <ul class="submenu">
				        <li><a href="PhanMat.php">Phấn mắt</a></li>
				        <li><a href="KeMat.php">Kẻ mắt</a></li>
				        <li><a href="Mascara.php">Mascara</a></li>
				        <li><a href="ChanMay.php">Chân mày</a></li>
				        <li><a href="LongMiGia.php">Lông mi giả</a></li>
		                <li><a href="PaletteChoMat.php">Pallette cho mắt</a></li>
		                <li><a href="CoMat.php">Cọ mắt</a></li>
		                <li><a href="DuongDaMat.php">Dưỡng da mắt</a></li>
				      </ul>
				    </li>
					<li><a href="#">MÔI</a>
			            <ul class="submenu">
			              <li><a href="#">Son bóng</a></li>
			              <li><a href="#">Son môi</a></li>
			              <li><a href="#">Kẻ môi</a></li>
			              <li><a href="#">Dưỡng môi</a></li>
			              <li><a href="#">Cọ môi</a></li>  
			            </ul>
          			</li>
					<li><a href="#">MẶT</a>
			            <ul class="submenu">
			              <li><a href="#">Dưỡng da</a></li>
			              <li><a href="#">Kem nền</a></li>
			              <li><a href="#">Che khuyết điểm</a></li>
			              <li><a href="#">Phấn</a></li>
			              <li><a href="#">Má hồng</a></li>
			              <li><a href="#">Pallette cho mặt</a></li>
			              <li><a href="#">Tạo khối</a></li>
			              <li><a href="#">Cọ</a></li>
			              <li><a href="#">Tẩy trang</a></li>
			              <li><a href="#">Kem lót</a></li>
			              <li><a href="#">Kem dưỡng trang điểm</a></li>
			              <li><a href="#">Trang điểm ánh nhũ</a></li>
			              <li><a href="#">Dụng cụ</a></li>  
			            </ul>
          			</li>
					<li><a href="#">MÓNG</a>
			            <ul class="submenu">
			              <li><a href="#">Sơn móng tay</a></li>
			              <li><a href="#">Sản phẩm cho móng</a></li>
			              <li><a href="#">Dụng cụ làm móng</a></li>
			            </ul>
          			</li>
					<li><a href="#">DỤNG CỤ</a>
			            <ul class="submenu">
			              <li><a href="#">Bộ cọ</a></li>
			              <li><a href="#">Cọ lẻ</a></li>
			              <li><a href="#">Bông phấn</a></li>
			              <li><a href="#">Phấn</a></li>
			              <li><a href="#">Phụ kiện trang điểm</a></li>
			              <li><a href="#">Hộp đựng</a></li>
			              <li><a href="#">Bấm mi</a></li>
			              <li><a href="#">Gương</a></li>
			              <li><a href="#">Đồ chuốt</a></li>
			              <li><a href="#">Nhíp</a></li>
			              <li><a href="#">Vẽ chân mày</a></li>  
			            </ul>
          			</li>
			  	</ul>
			</div>
			<div><p></p></div>
			<div class="sub-menu">
			  	<ul class="">
			  		<li>
			  			<a href="TrangChu.php">Trang chủ</a>
		  			</li>
					<li><a href="">Thanh toán</a></li>
			  	</ul>
			</div>
		
			<div class="shopper-informations">
				<div class="row">
					<div class="col-sm-7 clearfix">
						<div class="bill-to">
							<p>Gửi đến</p>
							<div class="form-one">
								<form action="ThongBao.php?xem=thongbao&id_kh=<?php echo $_GET['id_kh'] ?>" method="post" style="font-size: 12px;">
									 Email *
									<input type="text" name="gh_email" placeholder="Email *">
									 Người nhận*
									<input type="text" name="gh_ten" placeholder="Người nhận *">
									 Số điện thoại *
									<input type="text" name="gh_sodt" placeholder="Số điện thoại *">
									 Fax
									<input type="text" name="gh_fax" placeholder="Fax">
									 Địa chỉ *
									<input type="text" name="gh_diachi" placeholder="Địa chỉ *">
									 Quận/Huyện *
									<input type="text" name="gh_quanhuyen" placeholder="Quận/Huyện *">
									 Tỉnh * <br>
									<select name="tinh" placeholder="Tỉnh">
				                       	<option value="">-- Tỉnh * --</option>
				                        <option value="485" title="Hồ Chí Minh">Hồ Chí Minh</option>
				                        <option value="486" title="Hà Nội">Hà Nội</option>
				                        <option value="487" title="An Giang">An Giang</option>
				                        <option value="488" title="Bà Rịa Vũng Tàu">Bà Rịa Vũng Tàu</option>
				                        <option value="489" title="Bắc Kạn">Bắc Kạn</option>
				                        <option value="490" title="Bạc Liêu">Bạc Liêu</option>
				                        <option value="491" title="Bắc Ninh">Bắc Ninh</option>
				                        <option value="492" title="Bến Tre">Bến Tre</option>
				                        <option value="493" title="Bình Dương">Bình Dương</option>
				                        <option value="494" title="Bình Phước">Bình Phước</option>
				                        <option value="495" title="Bình Thuận">Bình Thuận</option>
				                        <option value="496" title="Bình Định">Bình Định</option>
				                        <option value="497" title="Cà Mau">Cà Mau</option>
				                        <option value="498" title="Cần Thơ">Cần Thơ</option>
				                        <option value="499" title="Cao Bằng">Cao Bằng</option>
				                        <option value="500" title="Gia Lai">Gia Lai</option>
				                        <option value="501" title="Hà Giang">Hà Giang</option>
				                        <option value="502" title="Hà Nam">Hà Nam</option>
				                        <option value="503" title="Hà Tĩnh">Hà Tĩnh</option>
				                        <option value="504" title="Hải Dương">Hải Dương</option>
				                        <option value="505" title="Hải Phòng">Hải Phòng</option>
				                        <option value="506" title="Hậu Giang">Hậu Giang</option>
				                        <option value="507" title="Hòa Bình">Hòa Bình</option>
				                        <option value="508" title="Hưng Yên">Hưng Yên</option>
				                        <option value="509" title="Khánh Hòa">Khánh Hòa</option>
				                        <option value="510" title="Kiên Giang">Kiên Giang</option>
				                        <option value="511" title="Kon Tum">Kon Tum</option>
				                        <option value="512" title="Lai Châu">Lai Châu</option>
				                        <option value="513" title="Lâm Đồng">Lâm Đồng</option>
				                        <option value="514" title="Lạng Sơn">Lạng Sơn</option>
				                        <option value="515" title="Lào Cai">Lào Cai</option>
				                        <option value="516" title="Long An">Long An</option>
				                        <option value="517" title="Nam Định">Nam Định</option>
				                        <option value="518" title="Nghệ An">Nghệ An</option>
				                        <option value="519" title="Ninh Bình">Ninh Bình</option>
				                        <option value="520" title="Ninh Thuận">Ninh Thuận</option>
				                        <option value="521" title="Phú Thọ">Phú Thọ</option>
				                        <option value="522" title="Phú Yên">Phú Yên</option>
				                        <option value="523" title="Quảng Bình">Quảng Bình</option>
				                        <option value="524" title="Quảng Nam">Quảng Nam</option>
				                        <option value="525" title="Quảng Ngãi">Quảng Ngãi</option>
				                        <option value="526" title="Quảng Ninh">Quảng Ninh</option>
				                        <option value="527" title="Quảng Trị">Quảng Trị</option>
				                        <option value="528" title="Sóc Trăng">Sóc Trăng</option>
				                        <option value="529" title="Sơn La">Sơn La</option>
				                        <option value="530" title="Tây Ninh">Tây Ninh</option>
				                        <option value="531" title="Thái Bình">Thái Bình</option>
				                        <option value="532" title="Thái Nguyên">Thái Nguyên</option>
				                        <option value="533" title="Thanh Hóa">Thanh Hóa</option>
				                        <option value="534" title="Thừa Thiên Huế">Thừa Thiên Huế</option>
				                        <option value="535" title="Tiền Giang">Tiền Giang</option>
				                        <option value="536" title="Trà Vinh">Trà Vinh</option>
				                        <option value="537" title="Tuyên Quang">Tuyên Quang</option>
				                        <option value="538" title="Vĩnh Long">Vĩnh Long</option>
				                        <option value="539" title="Vĩnh Phúc">Vĩnh Phúc</option>
				                        <option value="540" title="Yên Bái">Yên Bái</option>
				                        <option value="541" title="Đà Nẵng">Đà Nẵng</option>
				                        <option value="542" title="Đăk Lăk">Đăk Lăk</option>
				                        <option value="543" title="Đăk Nông">Đăk Nông</option>
				                        <option value="544" title="Điện Biên">Điện Biên</option>
				                        <option value="545" title="Đồng Nai">Đồng Nai</option>
				                        <option value="546" title="Đồng Tháp">Đồng Tháp</option>
									</select>
								</form>
							</div>
						</div>
					</div>
					<div class="col-sm-5">
						<div class="order-message">
							<p>Ghi chú</p>
							<textarea name="message"  placeholder="" rows="10"></textarea>
						</div>	
					</div>					
				</div>
			</div>
			<div class="review-payment">
				<h2>Hình thức thanh toán</h2>
				<div><input type="checkbox" name="thanhtoan" value="yes"> Thanh toán khi nhận hàng</div>
			</div>
			<div class="review-payment">
				<h2>Chi tiết</h2>
			</div>
			<div class="table-responsive cart_info">
				<table class="table table-condensed">
					<thead>
						<tr class="cart_menu" style="background: #111; color: white;">
							<td class="image">Sản phẩm</td>
							<td class="description"></td>
							<td class="price">Giá</td>
							<td class="quantity">Số lượng</td>
							<td class="total">Thành tiền</td>
							<td></td>
						</tr>
					</thead>
					<tbody>
					<?php
					include("../models/config.php");
					$id_kh=$_GET['id_kh'];
					
					$tongtien=0;
					foreach ($_SESSION as $name => $value) {
						if($value>0){
							if(substr($name,0,8)=='giohang_'){
								$id=substr($name,8,strlen($name-8));
								$sql="select * from chitietsanpham where id_sanpham='".$id."'";
								$rs=mysql_query($sql); 
								$sql_sp="select * from sanpham where id_sanpham='".$id."'";
								$rs_sp=mysql_query($sql_sp);
								while ($row=mysql_fetch_array($rs)) {
									while($row_sp=mysql_fetch_array($rs_sp)){
							  			$thanhtien=$row['Gia']*$value;
					?>
						<tr>
							<td class="cart_product">
								<img style="width: 100px; height: 100px;" src="image/<?php echo $row['Anh'] ?>" alt=""></td>
							<td class="cart_description">
								<h5 style="font-weight: bold;"><?php echo $row_sp['TenSanPham'] ?></h5>
							</td>
							<?php
								}  
							?>
							<td class="cart_price">
								<p><?php echo $row['Gia']?> VND</p>
							</td>
							<td class="cart_quantity">
								<div class="cart_quantity_button">
									<a href="giohang.php?xem=gio-hang&them=<?php echo $row['ID_SanPham'] ?>&id_kh=<?php echo $_GET['id_kh'] ?>" style="text-decoration: none; font-size: 18px; color: #ff1a75;"></a>
									<input readonly="true" class="cart_quantity_input" type="text" name="quantity" value="<?php echo $value ?>" autocomplete="off" size="2">
									<a href="giohang.php?xem=gio-hang&bo=<?php echo $row['ID_SanPham'] ?>&id_kh=<?php echo $_GET['id_kh'] ?>" style="text-decoration: none; font-size: 18px; color: #ff1a75;"></a>
								</div>
							</td>
							<td class="cart_total">
								<p class="cart_total_price"><?php echo $thanhtien ?> VND</p>
							</td>
							
						</tr>
						<?php
								}
								$tongtien+=$thanhtien;
								$_SESSION['tongtien']=$tongtien;
							}
						}
					}
						?>
					<tr>
						<td colspan="4">&nbsp;</td>
						<td colspan="2">
							<table class="table table-condensed total-result">
								<tr>
									<td style="font-weight: bold;">Tổng tiền</td>
									<td style="font-weight: bold;"><span><?php echo $tongtien; ?> VND</span></td>
								</tr>
							</table>
						</td>
					</tr>
					</tbody>
				</table>
			</div>
			<a href="ThongBao.php?xem=thongbao&id_kh=<?php echo $_GET['id_kh'] ?>"><button style="float: right; background: #ff1a75; color: white; font-weight: bold;" class="btn btn-default check_out" type="submit" name="hoanthanh">Hoàn thành</button></a>
			<!--<a href="checkout.php?xem=thanhtoan&id_kh=<?php echo $_GET['id_kh'] ?>"><input style="float: right; background: #ff1a75; color: white; font-weight: bold;" class="btn btn-default check_out" type="submit" name="hoanthanh" value="Hoàn thành"></a>-->
			<br>
			<section>
				<div>
					<p></p><br>
				</div>
			</section>
			<section class="about-sect">
				<div>
				  	<table id="table_3">
					    <tr>	
					      <th><p></p>Tại sao lại chọn chúng tôi?</th>
					    </tr>
					    <tr>
					    	<td>
					    		<p></p>
					    	</td>
					    </tr>
					    <tr>
					    	<td>gumiho cosmetics là nhãn hiệu mỹ phẩm không thể thiếu cho nhu cầu trang 
              					điểm và làm đẹp mỗi ngày của bạn. Tại gumiho, chúng tôi cung cấp những 
              					sản phẩm chất lượng với giá cả phải chăng đem lại nét rạng rỡ tự nhiên 
	              				cho gương mặt với sự đa dạng về chủng loại sản phẩm, son bóng quyến rũ 
	              				nhiều tông màu với nhiều kiểu dáng khác nhau cũng như son môi dưỡng 
	              				ẩm chuyên sâu đem lại màu sắc tươi tắn và lâu phai suốt cả ngày.
					    	</td>
					    </tr>
			            <tr>
			              <td><p></p></td>
			            </tr>
			            <tr>
			              <td>Bên cạnh đó, dòng sản phẩm trang điểm khoáng chất của gumiho an toàn không chứa màu 
	          				nhuộm hóa học và chất bảo quản giúp nuôi dưỡng làn da của bạn sáng bóng, khỏe mạnh hơn.
			              </td>
			            </tr>
					    <tr>
					    	<td>
					    		<p></p>
					    	</td>
					    </tr>
				    </table>
				</div>
				
	      		<p id="p">a</p>
				<div>
					<p class="font1"><br>Copyright &copy 2017 Gumiho Cosmetics VN. Powered by UIT</p>
				</div>
			</section>
			<div>
		        <table id="table_5">
		          <th><img src="image/peta.png" id="image"></th>
		          <th><img src="image/logo_client.png" id="image"></th>
		          <th><img src="image/paypal.png" id="image"></th>
		        </table>
			</div>
		</div>

	<!-- Right -->
		<div class="col-md-2" id="right"></div>

	<!-- Footer -->
  		<div class="col-md-12" id="footer" >
  			<table id="table_4">	
  					<tr>
  						<p></p>
  					</tr>
  					<tr>
  						<th id="column">SẢN PHẨM MỚI</th>
  						<th id="column">MẮT<p></p></th>
  						<th id="column">MÔI</th>
  						<th id="column">MẶT</th>
  						<th id="column">MÓNG</th>
  					</tr>
  					<tr>
  						<td>BÁN CHẠY</td>
  						<td>Phấn mắt</td>
  						<td>Son bóng</td>
  						<td>Dưỡng da</td>
  						<td>Sơn móng tay</td>
  					</tr>
  					<tr>
  						<td>BLOG LÀM ĐẸP</td>
  						<td>Kẻ mắt</td>
  						<td>Son môi</td>
  						<td>Kem nền</td>
  						<td>Sản phẩm cho móng</td>
  					</tr>
  					<tr>
  						<td></td>
  						<td>Mascara</td>
  						<td>Cọ môi</td>
  						<td>Che khuyết điểm</td>
  						<td>Dụng cụ làm móng</td>

  					</tr>
  					<tr>
  						<td></td>
  						<td>Cọ mắt</td>
  						<td></td>
  						<td>Phấn & Má hồng</td>
  						<td></td>
  					</tr>
  					<tr>
  						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  					</tr>
  					<tr>
  						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  					</tr>
  					<tr>
  						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  					</tr>
  					<tr>
  						<td></td>
  						<td></td>
  						<td></td> 
  						<td></td>
  					</tr>
  					<tr>
  						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  					</tr>
  					<tr>
  						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  					</tr>
  					<tr>
  						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  					</tr>
  					<tr>
  						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  					</tr>
  					<tr>
						<td></td>
  						<td></td>
  						<td></td>
  						<td></td>
  					</tr>
  			</table>
  		</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script> 
<script src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery-3.2.0.min.js"></script>
<script type="text/javascript" src="js/verticalmenu.js"></script>
</body>
</html>
<?php
	ob_flush();  
?>