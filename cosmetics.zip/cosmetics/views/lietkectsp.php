<?php
	include("models/config.php");
	$sql="select * from chitietsanpham where id_sanpham=$_GET[id] order by id_sanpham asc";
	$rs=mysql_query($sql);
	$row=mysql_fetch_array($rs);
?>
<div><p></p><br>
<table border=1 id="tab">
	<tr  style="border: 1px solid #111;">
		<th style="text-align: center;">Mã SP</th>
		<th style="text-align: center;">Màu sản phẩm</th>
		<th style="text-align: center;">Số lượng</th>
		<th style="text-align: center;">Giá</th>
		<th style="text-align: center;">Ảnh</th>
		<th style="text-align: center;">Giá KM</th>
		<th style="text-align: center;">Tình trạng</th>
		<th style="text-align: center;">Số lượng đã bán</th>
		<th style="text-align: center;" colspan="2">Quản lý</th>
	</tr>
    <!--<?php
    	/*if($rs === FALSE) { 
   	 		die(mysql_error()); // TODO: better error handling
		}
    	$i=1;
		while(){*/
	?>-->
	<tr>
		<td><?php echo $_GET['id'] ?></td>
        <td><?php echo $row['MauSP'] ?></td>
        <td><?php echo $row['SoLuong'] ?></td>
        <td><?php echo $row['Gia'] ?></td>
        <td><img src="views/image/<?php echo $row['Anh'] ?>" style="width: 100px; height: 100px;"></td>
        <td><?php echo $row['GiaKM'] ?></td>
        <td><?php echo $row['TinhTrang'] ?></td>
        <td><?php echo $row['SoLuongDaBan'] ?></td>
		<td><a href="QuanLySanPham.php?quanly=quanlyctsp&ac=sua&id=<?php echo $_GET['id']?>&id_admin=<?php echo $_GET['id_admin'] ?>">Sửa</a></td>
		<td><a href="models/ctsp.php?id=<?php echo $_GET['id']?>&id_admin=<?php echo $_GET['id_admin']?>">Xóa</a></td>
	</tr>
    <!--<?php
    	//$i++;
		//}
	?>-->
</table>
</div>