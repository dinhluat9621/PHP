<?php
	$sql="select * from admin where id=$_GET[id]";
	$rs=mysqli_query($conn,$sql);
	$dong=mysqli_fetch_array($rs);
	/*models/taikhoan.php?id=<?php echo $dong['ID_SanPham'] ?>*/
?>
<form action="models/taikhoan.php?id=<?php echo $dong['ID'] ?>" method="post" enctype="multipart/form-data"> 
<table width="1674" id="tab_2">
		<tr>
			<th width="347"></th>
			<th width="586"></th>
			<th width="558"></th>
            <th width="163"></th>
		</tr>
		<tr>
			<td>Mã tài khoản</td>
			<td>Tên đăng nhập</td>
			<td>Mật khẩu</td>
		</tr>
		<tr>
			<td><input type="Text" name="id_tk" id="id_tk" cols="30" rows="1" value=""><?php echo $dong['ID'] ?></td>
			<td><input type="Text" name="username" id="username" cols="30" rows="1" value=""><?php echo $dong['username'] ?></td>
			<td><input type="Text" name="password" id="password" cols="30" rows="1" value=""><?php echo $dong['password'] ?></td>
		</tr>
		<tr>
			<td><p></p></td>
			<td><p></p></td>
			<td><p></p></td>
		</tr>
		<tr>
			<td><input type="submit" name="sua" id="sua" value="Sửa"></td>
		</tr>
</table>
<div><p style="font-size: 21px; font-weight: bold; text-align: center; text-indent: 450px;">Danh sách tài khoản</p></div>
</form>
<div><p></p></div>