<form action="models/hoadon.php" method="post" enctype="multipart/form-data">
<table style="width: 1100px;">
		<tr>
			<th width="347"></th>
			<th width="586"></th>
			<th width="558"></th>
            <th width="163"></th>
		</tr>
		<tr>
			<td>Mã hóa đơn</td>
			<td>Tên khách hàng</td>
			<td>Mật khẩu</td>
		</tr>
		<tr>
			<td><input type="Text" name="id_tk" id="id_tk" cols="30" rows="1"></td>
			<?php
				$sql="select * from khachhang";
				$rs=mysqli_query($conn,$sql);  
			?>
			<td><select name="khachhang">
			<?php
				while ($row=mysqli_fetch_array($rs)) {
				  	# code...  
			?>
				<option value="<?php echo $row[0] ?>"><?php echo $row[1] ?></option>
			<?php
				}  
			?>
			</select></td>
			<td><input type="Text" name="thanhtien" id="thanhtien" cols="30" rows="1"></td>
		</tr>
		<tr>
			<td><p></p></td>
			<td><p></p></td>
			<td><p></p></td>
		</tr>
		<tr>
			<td><button name="them" value="Thêm">Thêm</button></td>
		</tr>
</table>
<div><p style="font-size: 21px; font-weight: bold; text-align: center; text-indent: 450px;">Danh sách hóa đơn</p></div>
</form>
