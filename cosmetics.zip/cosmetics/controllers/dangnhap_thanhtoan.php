<?php
	include('../models/config.php');
	session_start();
	if(isset($_POST['login_checkout'])){
		$email=$_POST['email'];
		$matkhau=$_POST['matkhau'];
		$sql="select * from khachhang where email='$email' and matkhau='$matkhau' limit 1";
		$query=mysql_query($sql);
		$num=mysql_num_rows($query);
		if($num>0){
			$_SESSION['dangnhap']=$username;
			header('location:views/checkout.php');
		}
		else{
			header('location:dangnhap_thanhtoan.php');	
		}
	}  
?>