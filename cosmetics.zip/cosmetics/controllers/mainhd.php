<div class="section-1">
	<?php
		if (isset($_GET['ac'])) {
		 	# code...
		 	$tam=$_GET['ac'];
		 } 
		 else{
		 	$tam='';
		 }
		 if ($tam=='them') {
		 	# code...
		 	include("views/themhd.php");
		 }
		 if ($tam=='sua') {
		 	# code...
		 	include("views/suahd.php");
		 }
	 ?>
</div>
<div class="sectioin-2">
	<?php
		include("views/lietkehd.php");  
	?>
</div>