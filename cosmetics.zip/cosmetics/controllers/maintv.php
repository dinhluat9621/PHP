<div class="section-1">
	<?php
		if (isset($_GET['ac'])) {
		 	# code...
		 	$tam=$_GET['ac'];
		 } 
		 else{
		 	$tam='';
		 }
		 if ($tam=='them') {
		 	# code...
		 	include("views/themtv.php");
		 }
		 if ($tam=='sua') {
		 	# code...
		 	include("views/suatv.php");
		 }
	 ?>
</div>
<div class="sectioin-2">
	<?php
		include("views/lietketv.php");  
	?>
</div>