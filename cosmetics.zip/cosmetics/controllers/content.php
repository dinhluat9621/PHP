<div class="content">
<?php 
	if (isset($_GET['quanly'])) {
		# code...
		$tam=$_GET['quanly'];
	}
	else{
		$tam='';
	}
	if ($tam=='quanlysp') {
		# code...
		include("controllers/mainsp.php");
	}
	if ($tam=='quanlyctsp') {
		# code...
		include("controllers/mainctsp.php");
	}
	if ($tam=='quanlyloaisp') {
		# code...
		include("controllers/mainloaisp.php");
	}
	if ($tam=='quanlytk') {
		# code...
		include("controllers/maintk.php");
	}
	if ($tam=='quanlyhd') {
		# code...
		include("controllers/mainhd.php");
	}
	if ($tam=='quanlybl') {
		# code...
		include("controllers/mainbl.php");
	}
	if ($tam=='quanlytv') {
		# code...
		include("controllers/maintv.php");
	}
?>
</div>