<?php
	include("../models/config.php");
	$id=$_GET['id'];
	$mahd=$_POST['id_hd'];
	$makh=$_POST['id_kh'];
	$thanhtien=$_POST['thanhtien'];
	if(isset($_POST['them'])){
		$sql="insert into hoadon(id_hd, id_kh, thanhtien) values('$mahd','$makh','$thanhtien')";
		mysqli_query($conn,$sql);
		header('location:../QuanLyHoaDon.php?quanly=quanlyhd&ac=them');
	}
	elseif (isset($_POST['sua'])) {
		$sql="update hoadon set id_hd='$mahd', id_kh='$makh', thanhtien='$thanhtien' where id='$id'";
		mysqli_query($conn,$sql);
		/*header('location:../QuanLySanPham.php?quanly=quanlysp&ac=sua&id='.$id);*/
		header('location:../QuanLyHoaDon.php?quanly=quanlyhd&ac=them');
	}
	else{
		$sql="delete from hoadon where id='$id'";
		mysqli_query($conn,$sql);
		header('location:../QuanLyHoaDon.php?quanly=quanlyhd&ac=them');
	}

?>