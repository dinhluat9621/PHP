<?php
	include("../models/config.php");
	$id_admin=$_GET['id_admin'];
	$id=$_GET['id'];
	$masp=$_POST['id_sp'];
	$mausp=$_POST['mausp'];
	$soluong=$_POST['sl'];
	$gia=$_POST['gia'];
	$anh=$_FILES['anh']['name'];
	$anh_tmp=$_FILES['anh']['name_tmp'];
	move_uploaded_file($anh_tmp,'/image'.$anh);
	$giakm=$_POST['giakm'];
	$tinhtrang=$_POST['tinhtrang'];
	$soluongdb=$_POST['sldb'];
	if(isset($_POST['them'])){
		$sql="insert into chitietsanpham(id_sanpham, mausp, soluong, gia, anh, giakm, tinhtrang, soluongdaban) values('$masp','$mausp','$soluong','$gia','$anh','$giakm','$tinhtrang','$soluongdb')";
		mysql_query($sql,$conn);
		header('location:../QuanLySanPham.php?quanly=quanlyctsp&ac=them&id='.$id.'&id_admin='.$id_admin);
	}
	elseif (isset($_POST['sua'])) {
		if($anh!=''){
			$sql="update chitietsanpham set id_sanpham='$masp', mausp='$mausp', soluong='$soluong',gia='$gia',anh='$anh',giakm='$giakm',tinhtrang='$tinhtrang',soluongdaban='$soluongdb' where id_sanpham='$id'";
		}
		else{
			$sql="update chitietsanpham set id_sanpham='$masp', mausp='$mausp', soluong='$soluong',gia='$gia',giakm='$giakm',tinhtrang='$tinhtrang',soluongdaban='$soluongdb' where id_sanpham='$id'";	
		}
		mysql_query($sql,$conn);
		header('location:../QuanLySanPham.php?quanly=quanlyctsp&ac=them&id='.$id.'&id_admin='.$id_admin);
	}
	else{
		$sql="delete from chitietsanpham where id_sanpham='$id'";
		mysql_query($sql,$conn);
		header('location:../QuanLySanPham.php?quanly=quanlyctsp&ac=them&id='.$id.'&id_admin='.$id_admin);
	}

?>