<?php
	include("../models/config.php");
	$id=$_GET['id'];
	$matk=$_POST['id_tk'];
	$username=$_POST['username'];
	$password=$_POST['password'];
	if(isset($_POST['them'])){
		$sql="insert into admin(id, username, password) values('$matk','$username','$password')";
		mysqli_query($conn,$sql);
		header('location:../QuanLyTaiKhoan.php?quanly=quanlytk&ac=them');
	}
	elseif (isset($_POST['sua'])) {
		$sql="update admin set id='$matk', username='$username', password='$password' where id='$id'";
		mysqli_query($conn,$sql);
		/*header('location:../QuanLySanPham.php?quanly=quanlysp&ac=sua&id='.$id);*/
		header('location:../QuanLyTaiKhoan.php?quanly=quanlytk&ac=them');
	}
	else{
		$sql="delete from admin where id='$id'";
		mysqli_query($conn,$sql);
		header('location:../QuanLyTaiKhoan.php?quanly=quanlytk&ac=them');
	}

?>