<?php
	include("../models/config.php");
	$id=$_GET['id'];
	$mablog=$_POST['id_blog'];
	$anh=$_POST['anh'];
	$noidung=$_POST['noidung'];
	if(isset($_POST['them'])){
		$sql="insert into blog(id_blog, anh, noidung) values('$mablog','$anh','$noidung')";
		mysqli_query($conn,$sql);
		header('location:../QuanLyBlog.php?quanly=quanlybl&ac=them');
	}
	elseif (isset($_POST['sua'])) {
		$sql="update blog set id_blog='$mablog', anh='$anh', noidung='$noidung' where id='$id'";
		mysqli_query($conn,$sql);
		/*header('location:../QuanLySanPham.php?quanly=quanlysp&ac=sua&id='.$id);*/
		header('location:../QuanLyBlog.php?quanly=quanlybl&ac=them');
	}
	else{
		$sql="delete from blog where id='$id'";
		mysqli_query($conn,$sql);
		header('location:../QuanLyBlog.php?quanly=quanlybl&ac=them');
	}

?>