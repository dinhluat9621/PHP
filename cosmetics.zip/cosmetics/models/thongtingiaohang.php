<?php
	if(isset($_POST['hoanthanh'])){
						
						$email=$_POST['email'];
						$_SESSION['nguoinhan']=$_POST['ten'];
						$_SESSION['sdt']=$_POST['sodt'];
						$_SESSION['fax']=$_POST['fax'];
						$_SESSION['diachi']=$_POST['diachi'];
						$_SESSION['quan']=$_POST['quanhuyen'];
						$_SESSION['tinh']=$_POST['tinh'];
						$_SESSION['ghichu']=$_POST['ghichu'];
											header('location:ThongBao.php?xem=thongbao&ac=dat&id_kh='.$id_kh);

					}  
?>