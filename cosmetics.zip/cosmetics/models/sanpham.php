<?php
	include("../models/config.php");
    $id_admin=$_GET['id_admin'];
	$id=$_GET['id'];
	$masp=$_POST['id_sp'];
	$loaisp=$_POST['loaisp'];
	$tensp=$_POST['tensp'];
	$thongtin=$_POST['ttsp'];
	$hdsd=$_POST['hdsd'];
	if(isset($_POST['them'])){
		$sql="insert into sanpham(id_sanpham, id_loaisp, tensanpham, thongtinsp, huongdansd, ngaythem) values('$masp','$loaisp','$tensp','$thongtin','$hdsd',CURDATE())";
		mysql_query($sql,$conn);
		header('location:../QuanLySanPham.php?quanly=quanlysp&ac=them&id_admin='.$id_admin);
	}
	elseif (isset($_POST['sua'])) {
		$sql="update sanpham set id_sanpham='$masp', id_loaisp='$loaisp', tensanpham='$tensp', thongtinsp='$thongtin', huongdansd='$hdsd' where id_sanpham='$id'";
		mysql_query($sql,$conn);
		/*header('location:../QuanLySanPham.php?quanly=quanlysp&ac=sua&id='.$id);*/
		header('location:../QuanLySanPham.php?quanly=quanlysp&ac=them&id_admin='.$id_admin);
	}
	else{
		$sql="delete from sanpham where id_sanpham='$id'";
		mysql_query($sql,$conn);
		header('location:../QuanLySanPham.php?quanly=quanlysp&ac=them&id_admin='.$id_admin);
	}

?>