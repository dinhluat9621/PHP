<?php
	include("../models/config.php");
	$sql="select * from admin where id=$_GET[id_admin]";
    $rs=mysql_query($sql);
    $row=mysql_fetch_array($rs);
    $id_admin=$_GET['id_admin'];
	$id=$_GET['id'];
	$maloaisp=$_POST['id_loaisp'];
	$tenloaisp=$_POST['tenloaisp'];
	$tendm=$_POST['tendm'];
	if(isset($_POST['them'])){
		$sql="insert into loaisanpham(id_loaisp, tenloaisp, tendanhmuc) values('$maloaisp','$tenloaisp','$tendm')";
		mysql_query($sql,$conn);
		header('location:../QuanLySanPham.php?quanly=quanlyloaisp&ac=them&id_admin='.$id_admin);
	}
	elseif (isset($_POST['sua'])) {
		$sql="update loaisanpham set tenloaisp='$tenloaisp', tendanhmuc='$tendm' where id_loaisp='$id'";
		mysql_query($sql,$conn);
		/*header('location:../QuanLySanPham.php?quanly=quanlysp&ac=sua&id='.$id);*/
		header('location:../QuanLySanPham.php?quanly=quanlyloaisp&ac=them&id_admin='.$id_admin);
	}
	else{
		$sql="delete from loaisanpham where id_loaisp='$id'";
		mysql_query($sql);
		header('location:../QuanLySanPham.php?quanly=quanlyloaisp&ac=them&id_admin='.$id_admin);
	}

?>