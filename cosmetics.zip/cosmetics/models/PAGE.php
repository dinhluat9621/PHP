<?php  
	include("../models/config.php");
	$perpage=6;
	if(isset($_GET["trang"])){
		$current_page=$_GET['trang'];
		settype($current_page,"int");
	}
	else{
		$current_page=1;
	}
	$start=($current_page-1)*$perpage;
	$sql="select * from sanpham sp, chitietsanpham ct where sp.id_loaisp=6 and ct.id_sanpham=sp.id_sanpham limit $start, $perpage";
	$rs=mysql_query($sql);
	
	while($row=mysql_fetch_array($rs)){
?>
<ul style="width: 100%; list-style-type: none;">
	<li style="width: 210px; height: auto; text-align: center; font-weight: bold; float: left; margin-left: 20px;">
		<img src="image/<?php echo $row['Anh'] ?>" style="width: 150px; height: 150px;">
		<p style="color: #404040;"><?php echo $row['TenSanPham'] ?></p>
		<p style="color: #404040;">Giá: <?php echo number_format($row['Gia'] , 0) ?></p>
	</li>
</ul>
<?php
	}
	$x=mysql_query("select id_sanpham from sanpham where id_loaisp=6");
	$total_rows=mysql_num_rows($x);
	$num_pages=ceil($total_rows/$perpage);
	for ($t=1; $t<=$num_pages; $t++){  
		echo "<a href='SonMoi.php?trang=$t'>Trang $t</a> - ";
	}
?>