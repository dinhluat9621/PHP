<?php
	include("../models/config.php");
	$id=$_GET['id'];
	$matv=$_POST['id_kh'];
	$hoten=$_POST['hoten'];
	$diachi=$_POST['diachi'];
	$quan=$_POST['quan_huyen'];
	$tinh=$_POST['tinh'];
	$sdt=$_POST['sodienthoai'];
	$email=$_POST['email'];
	$password=$_POST['matkhau'];

	if(isset($_POST['them'])){
		$sql="insert into khachhang(id_kh, hoten, diachi, quan_huyen, tinh, sodienthoai, email, matkhau) values('$matv','$hoten','$diachi','$quan','$tinh', '$sdt', '$email', '$password')";
		mysqli_query($conn,$sql);
		header('location:../QuanLyThanhVien.php?quanly=quanlytv&ac=them');
	}
	elseif (isset($_POST['sua'])) {
		$sql="update khachhang set id_kh='$matv', hoten='$hoten', diachi='$diachi', quan_huyen='$quan', tinh='$tinh', sodienthoai='$sdt', email='$email', matkhau='$password' where id_kh='$id'";
		mysqli_query($conn,$sql);
		/*header('location:../QuanLySanPham.php?quanly=quanlysp&ac=sua&id='.$id);*/
		header('location:../QuanLyThanhVien.php?quanly=quanlytv&ac=them');
	}
	else{
		$sql="delete from khachhang where id_kh='$id'";
		mysqli_query($conn,$sql);
		header('location:../QuanLyThanhVien.php?quanly=quanlytv&ac=them');
	}

?>